﻿using System;
using System.Collections.Generic;
using mem_help;

namespace stat_asm
{
	// Token: 0x02000004 RID: 4
	public static class sasm
	{
		// Token: 0x06000004 RID: 4 RVA: 0x000021B0 File Offset: 0x000003B0
		public static short fretn(IntPtr epilogue)
		{
			bool flag = mem.sreadb(epilogue, 1) == "C2";
			short result;
			if (flag)
			{
				result = convert.to_short(mem.readb(epilogue + 1), mem.readb(epilogue + 2));
			}
			else
			{
				result = 0;
			}
			return result;
		}

		// Token: 0x06000005 RID: 5 RVA: 0x000021FC File Offset: 0x000003FC
		public static List<string> fargs(IntPtr function)
		{
			List<string> list = new List<string>();
			RESULTS results = sasm.scanning.scancall(mem.BASE, mem.STACK_END, function);
			bool flag = results.Count == 0;
			List<string> result;
			if (flag)
			{
				result = list;
			}
			else
			{
				string a = sasm.calltype(function);
				int num = 0;
				while (list.Count == 0 && num < results.Count)
				{
					IntPtr intPtr = results[num];
					IntPtr intPtr2 = sasm.nextprologue(intPtr, direction.BEHIND);
					List<opcode> list2 = sasm.reader.read(intPtr2, intPtr);
					int num2 = 0;
					int num3 = 0;
					int num4 = 0;
					int num5 = 0;
					int num6 = 0;
					int num7 = 0;
					int num8 = 0;
					int num9 = 0;
					int num10 = list2.Count - 1;
					opcode opcode = new opcode();
					opcode.address = intPtr;
					while ((int)opcode.address > (int)(intPtr - 16) && (int)opcode.address > (int)(intPtr2 + 3) && num10 > 0)
					{
						opcode = list2[num10];
						bool flag2 = sasm.reader.checkstr(opcode.asm, 0, "call ");
						if (flag2)
						{
							break;
						}
						bool flag3 = a == "__fastcall";
						if (flag3)
						{
							bool flag4 = sasm.reader.checkstr(opcode.asm, 0, "mov ecx,") && num8 == 0;
							if (flag4)
							{
								bool flag5 = opcode.asm.Length != 11;
								if (flag5)
								{
									list.Add("int");
								}
								else
								{
									list.Add("var");
								}
								num8 = 1;
							}
							bool flag6 = sasm.reader.checkstr(opcode.asm, 0, "mov edx,") && num9 == 0;
							if (flag6)
							{
								bool flag7 = opcode.asm.Length != 11;
								if (flag7)
								{
									list.Add("int");
								}
								else
								{
									list.Add("var");
								}
								num9 = 1;
							}
							bool flag8 = sasm.reader.checkstr(opcode.asm, 0, "or edx,");
							if (flag8)
							{
								bool flag9 = opcode.asm.Length != 10;
								if (flag9)
								{
									list.Add("int");
								}
								else
								{
									list.Add("var");
								}
							}
						}
						bool flag10 = sasm.reader.checkstr(opcode.asm, 0, "push eax") && num2 == 0;
						if (flag10)
						{
							list.Add("var");
							num2 = 1;
						}
						else
						{
							bool flag11 = sasm.reader.checkstr(opcode.asm, 0, "push ecx") && num3 == 0;
							if (flag11)
							{
								list.Add("var");
								num3 = 1;
							}
							else
							{
								bool flag12 = sasm.reader.checkstr(opcode.asm, 0, "push edx") && num4 == 0;
								if (flag12)
								{
									list.Add("var");
									num4 = 1;
								}
								else
								{
									bool flag13 = sasm.reader.checkstr(opcode.asm, 0, "push ebx") && num5 == 0;
									if (flag13)
									{
										list.Add("var");
										num5 = 1;
									}
									else
									{
										bool flag14 = sasm.reader.checkstr(opcode.asm, 0, "push esi") && num6 == 0;
										if (flag14)
										{
											list.Add("var");
											num6 = 1;
										}
										else
										{
											bool flag15 = sasm.reader.checkstr(opcode.asm, 0, "push edi") && num7 == 0;
											if (flag15)
											{
												list.Add("var");
												num7 = 1;
											}
											else
											{
												bool flag16 = sasm.reader.checkstr(opcode.asm, 0, "push ") && opcode.asm.Length != 8;
												if (flag16)
												{
													bool flag17 = sasm.reader.sub(opcode.asm, opcode.asm.Length - 5, 5) == "bytes";
													if (flag17)
													{
														list.Add("int");
													}
													else
													{
														bool flag18 = sasm.reader.checkstr(opcode.asm, 5, "value/offset:");
														if (flag18)
														{
															bool flag19 = mem.sreads(convert.to_addr(sasm.reader.sub(opcode.asm, 18, 8))).Length >= 2;
															if (flag19)
															{
																list.Add("const char*");
															}
														}
														else
														{
															bool flag20 = sasm.reader.sub(opcode.asm, 0, 5) == "push ";
															if (flag20)
															{
																list.Add("var");
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
						num10--;
					}
					num++;
				}
				bool flag21 = a == "__fastcall";
				if (flag21)
				{
					list.Reverse();
				}
				result = list;
			}
			return result;
		}

		// Token: 0x06000006 RID: 6 RVA: 0x000026C0 File Offset: 0x000008C0
		public static IntPtr nextprologue(IntPtr func_address, direction d)
		{
			for (int i = 0; i < 2048; i++)
			{
				bool flag = d == direction.BEHIND;
				if (flag)
				{
					bool flag2 = mem.sreadb(func_address - i, 3) == sasm.refer.PUSH_EBP + " 8B EC";
					if (flag2)
					{
						return func_address - i;
					}
					bool flag3 = mem.sreadb(func_address - i, 3) == sasm.refer.PUSH_ESI + " 8B F1";
					if (flag3)
					{
						return func_address - i;
					}
				}
				else
				{
					bool flag4 = d == direction.AHEAD;
					if (flag4)
					{
						bool flag5 = mem.sreadb(func_address + i, 3) == sasm.refer.PUSH_EBP + " 8B EC";
						if (flag5)
						{
							return func_address + i;
						}
						bool flag6 = mem.sreadb(func_address + i, 3) == sasm.refer.PUSH_ESI + " 8B F1";
						if (flag6)
						{
							return func_address + i;
						}
					}
				}
			}
			return func_address;
		}

		// Token: 0x06000007 RID: 7 RVA: 0x000027D8 File Offset: 0x000009D8
		public static IntPtr nextepilogue(IntPtr func_address, direction d)
		{
			for (int i = 0; i < 2048; i++)
			{
				bool flag = d == direction.BEHIND;
				if (flag)
				{
					bool flag2 = mem.sreadb(func_address - i, 2) == sasm.refer.POP_EBP + " C2";
					if (flag2)
					{
						return func_address - i + 1;
					}
					bool flag3 = mem.sreadb(func_address - i, 2) == sasm.refer.POP_ESI + " C2";
					if (flag3)
					{
						return func_address - i + 1;
					}
					bool flag4 = mem.sreadb(func_address - i, 2) == sasm.refer.POP_EBP + " C3";
					if (flag4)
					{
						return func_address - i + 1;
					}
					bool flag5 = mem.sreadb(func_address - i, 2) == sasm.refer.POP_ESI + " C3";
					if (flag5)
					{
						return func_address - i + 1;
					}
				}
				else
				{
					bool flag6 = d == direction.AHEAD;
					if (flag6)
					{
						bool flag7 = mem.sreadb(func_address + i, 2) == sasm.refer.POP_EBP + " C2";
						if (flag7)
						{
							return func_address + i + 1;
						}
						bool flag8 = mem.sreadb(func_address + i, 2) == sasm.refer.POP_ESI + " C2";
						if (flag8)
						{
							return func_address + i + 1;
						}
						bool flag9 = mem.sreadb(func_address + i, 2) == sasm.refer.POP_EBP + " C3";
						if (flag9)
						{
							return func_address + i + 1;
						}
						bool flag10 = mem.sreadb(func_address + i, 2) == sasm.refer.POP_ESI + " C3";
						if (flag10)
						{
							return func_address + i + 1;
						}
						bool flag11 = mem.sreadb(func_address + i, 2) == "CC CC";
						if (flag11)
						{
							return func_address + i;
						}
					}
				}
			}
			return func_address;
		}

		// Token: 0x06000008 RID: 8 RVA: 0x00002A24 File Offset: 0x00000C24
		public static IntPtr getcall(IntPtr address)
		{
			int num = mem.readi(address + 1);
			bool flag = mem.sreadb(address, 1) == sasm.refer.CALL && num != 0 && num > -33554431 && num < 33554431;
			IntPtr result;
			if (flag)
			{
				result = address + 5 + num;
			}
			else
			{
				result = mem.PZERO;
			}
			return result;
		}

		// Token: 0x06000009 RID: 9 RVA: 0x00002A88 File Offset: 0x00000C88
		public static IntPtr nextcall(IntPtr address, direction d)
		{
			for (int i = 0; i < 2048; i++)
			{
				bool flag = d == direction.AHEAD;
				if (flag)
				{
					IntPtr intPtr = address + i;
					int num = mem.readi(intPtr + 1);
					bool flag2 = mem.sreadb(intPtr, 1) == sasm.refer.CALL && num != 0 && num > -33554431 && num < 33554431;
					if (flag2)
					{
						return sasm.getcall(intPtr);
					}
				}
				else
				{
					bool flag3 = d == direction.BEHIND;
					if (flag3)
					{
						IntPtr intPtr2 = address - i;
						int num2 = mem.readi(intPtr2 + 1);
						bool flag4 = mem.sreadb(intPtr2, 1) == sasm.refer.CALL && num2 != 0 && num2 > -33554431 && num2 < 33554431;
						if (flag4)
						{
							return sasm.getcall(intPtr2);
						}
					}
				}
			}
			return mem.PZERO;
		}

		// Token: 0x0600000A RID: 10 RVA: 0x00002B80 File Offset: 0x00000D80
		public static RESULTS getcalls(IntPtr func, bool go_to_prologue)
		{
			RESULTS results = new RESULTS();
			sasm.subroutine subroutine;
			if (go_to_prologue)
			{
				subroutine = new sasm.subroutine(sasm.nextprologue(func, direction.BEHIND));
			}
			else
			{
				subroutine = new sasm.subroutine(func);
			}
			for (int i = 0; i < subroutine.size; i++)
			{
				int num = mem.readi(subroutine.start + i + 1);
				bool flag = mem.sreadb(subroutine.start + i, 1) == sasm.refer.CALL && num != 0 && num > -33554431 && num < 33554431;
				if (flag)
				{
					results.Add(sasm.getcall(subroutine.start + i));
					i += 4;
				}
			}
			return results;
		}

		// Token: 0x0600000B RID: 11 RVA: 0x00002C4C File Offset: 0x00000E4C
		public static string calltype(IntPtr func)
		{
			sasm.subroutine subroutine = new sasm.subroutine(func);
			string text = "";
			bool flag = mem.sreadb(func + 3, 2) == "85 D2";
			if (flag)
			{
				text = "__fastcall";
			}
			bool flag2 = mem.sreadb(func, 3) == "56 8B F1";
			if (flag2)
			{
				text = "__fastcall";
			}
			RESULTS results = sasm.scanning.scancall(mem.BASE, mem.STACK_END, func);
			bool flag3 = results.Count == 0;
			string result;
			if (flag3)
			{
				result = "unused function";
			}
			else
			{
				bool flag4 = text == "" && results.Count > 0;
				if (flag4)
				{
					IntPtr intPtr = results[0];
					IntPtr pointer = intPtr + 5;
					IntPtr intPtr2 = sasm.nextprologue(intPtr, direction.BEHIND);
					List<opcode> list = sasm.reader.read(intPtr2, intPtr);
					int num = list.Count - 1;
					opcode opcode = new opcode();
					opcode.address = intPtr;
					while ((int)opcode.address > (int)(intPtr - 16) && (int)opcode.address > (int)(intPtr2 + 3) && num > 0)
					{
						opcode = list[num];
						bool flag5 = sasm.reader.checkstr(opcode.asm, 0, "call ");
						if (flag5)
						{
							break;
						}
						bool flag6 = sasm.reader.checkstr(opcode.asm, 0, "sub esp,");
						if (flag6)
						{
							text = "__thiscall";
						}
						bool flag7 = sasm.reader.checkstr(opcode.asm, 0, "mov edx,");
						if (flag7)
						{
							text = "__fastcall";
						}
						bool flag8 = sasm.reader.checkstr(opcode.asm, 0, "mov ecx,");
						if (flag8)
						{
							text = "__fastcall";
						}
						bool flag9 = sasm.reader.checkstr(opcode.asm, 0, "or edx,");
						if (flag9)
						{
							text = "__fastcall";
						}
						bool flag10 = sasm.reader.checkstr(opcode.asm, 0, "lea ecx,");
						if (flag10)
						{
							text = "__fastcall";
						}
						num--;
					}
					bool flag11 = subroutine.stack_ret == 0;
					if (flag11)
					{
						int num2 = 0;
						while (num2 < 12 && !(mem.sreadb(pointer + num2, 1) == "E8"))
						{
							bool flag12 = mem.sreadb(pointer + num2, 2) == "8B F0" && mem.readb(pointer + num2) != 80;
							if (flag12)
							{
								text = "__cdecl";
							}
							bool flag13 = mem.sreadb(pointer + num2, 2) == "83 C4";
							if (flag13)
							{
								text = "__cdecl";
							}
							num2++;
						}
					}
				}
				bool flag14 = text == "";
				if (flag14)
				{
					text = "__stdcall";
				}
				result = text;
			}
			return result;
		}

		// Token: 0x0600000C RID: 12 RVA: 0x00002F34 File Offset: 0x00001134
		public static IntPtr pnext(IntPtr address, string array_of_bytes, direction d)
		{
			cbyte cbyte = new cbyte(array_of_bytes);
			for (int i = 0; i < 2048; i += 4)
			{
				bool flag = d == direction.AHEAD;
				if (flag)
				{
					bool flag2 = mem.sreadb(mem.pointer(address + i), cbyte.size()) == cbyte.to_string();
					if (flag2)
					{
						return address + i;
					}
				}
				else
				{
					bool flag3 = d == direction.BEHIND && mem.sreadb(mem.pointer(address - i), cbyte.size()) == cbyte.to_string();
					if (flag3)
					{
						return address - i;
					}
				}
			}
			return mem.PZERO;
		}

		// Token: 0x0600000D RID: 13 RVA: 0x00002FE8 File Offset: 0x000011E8
		public static IntPtr pnextstring(IntPtr address, string text, direction d)
		{
			for (int i = 0; i < 2048; i += 4)
			{
				bool flag = d == direction.AHEAD;
				if (flag)
				{
					bool flag2 = mem.sreads(mem.pointer(address + i), text.Length) == text;
					if (flag2)
					{
						return address + i;
					}
				}
				else
				{
					bool flag3 = d == direction.BEHIND && mem.sreads(mem.pointer(address - i), text.Length) == text;
					if (flag3)
					{
						return address - i;
					}
				}
			}
			return mem.PZERO;
		}

		// Token: 0x0200001B RID: 27
		public static class refer
		{
			// Token: 0x06000065 RID: 101 RVA: 0x00006754 File Offset: 0x00004954
			public static bool byte_in_offset(IntPtr address)
			{
				sasm.refer.calls_only_avoid = new List<string>();
				sasm.refer.calls_only_avoid.Add(sasm.refer.CMP_OFFSET);
				sasm.refer.calls_only_avoid.Add(sasm.refer.LEA_OFFSET);
				sasm.refer.calls_only_avoid.Add(sasm.refer.ADD_4BYTE);
				sasm.refer.calls_only_avoid.Add(sasm.refer.MOV_REG_OFFSET);
				sasm.refer.calls_only_avoid.Add(sasm.refer.MOV_OFFSET_REG);
				sasm.refer.calls_only_avoid.Add(sasm.refer.MOV_DWORD_PTR);
				int i = 0;
				while (i < sasm.refer.calls_only_avoid.Count)
				{
					int count = sasm.refer.calls_only_avoid[i].Replace(" ", "").Length / 2;
					bool flag = mem.sreadb(address - 1, count) == sasm.refer.calls_only_avoid[i];
					bool result;
					if (flag)
					{
						result = true;
					}
					else
					{
						bool flag2 = mem.sreadb(address - 2, count) == sasm.refer.calls_only_avoid[i];
						if (flag2)
						{
							result = true;
						}
						else
						{
							bool flag3 = mem.sreadb(address - 3, count) == sasm.refer.calls_only_avoid[i];
							if (!flag3)
							{
								i++;
								continue;
							}
							result = true;
						}
					}
					return result;
				}
				return false;
			}

			// Token: 0x06000066 RID: 102 RVA: 0x0000688C File Offset: 0x00004A8C
			public static bool byte_in_call(IntPtr address)
			{
				return (mem.sreadb(address - 4, 1) == sasm.refer.CALL && !sasm.refer.byte_in_offset(address - 4)) || (mem.sreadb(address - 3, 1) == sasm.refer.CALL && !sasm.refer.byte_in_offset(address - 3)) || (mem.sreadb(address - 2, 1) == sasm.refer.CALL && !sasm.refer.byte_in_offset(address - 2)) || (mem.sreadb(address - 1, 1) == sasm.refer.CALL && !sasm.refer.byte_in_offset(address - 1));
			}

			// Token: 0x04000057 RID: 87
			public static string JMP = "E9";

			// Token: 0x04000058 RID: 88
			public static string CALL = "E8";

			// Token: 0x04000059 RID: 89
			public static string PUSH_EAX = "50";

			// Token: 0x0400005A RID: 90
			public static string PUSH_ECX = "51";

			// Token: 0x0400005B RID: 91
			public static string PUSH_EDX = "52";

			// Token: 0x0400005C RID: 92
			public static string PUSH_EBX = "53";

			// Token: 0x0400005D RID: 93
			public static string PUSH_ESP = "54";

			// Token: 0x0400005E RID: 94
			public static string PUSH_EBP = "55";

			// Token: 0x0400005F RID: 95
			public static string PUSH_ESI = "56";

			// Token: 0x04000060 RID: 96
			public static string PUSH_EDI = "57";

			// Token: 0x04000061 RID: 97
			public static string POP_EAX = "58";

			// Token: 0x04000062 RID: 98
			public static string POP_ECX = "59";

			// Token: 0x04000063 RID: 99
			public static string POP_EDX = "5A";

			// Token: 0x04000064 RID: 100
			public static string POP_EBX = "5B";

			// Token: 0x04000065 RID: 101
			public static string POP_ESP = "5C";

			// Token: 0x04000066 RID: 102
			public static string POP_EBP = "5D";

			// Token: 0x04000067 RID: 103
			public static string POP_ESI = "5E";

			// Token: 0x04000068 RID: 104
			public static string POP_EDI = "5F";

			// Token: 0x04000069 RID: 105
			public static string CMP_OFFSET = "3D";

			// Token: 0x0400006A RID: 106
			public static string LEA_OFFSET = "8D";

			// Token: 0x0400006B RID: 107
			public static string ADD_4BYTE = "81";

			// Token: 0x0400006C RID: 108
			public static string MOV_REG_OFFSET = "8B";

			// Token: 0x0400006D RID: 109
			public static string MOV_OFFSET_REG = "89";

			// Token: 0x0400006E RID: 110
			public static string MOV_DWORD_PTR = "C7";

			// Token: 0x0400006F RID: 111
			public static string RETN = "C2";

			// Token: 0x04000070 RID: 112
			public static string RET = "C3";

			// Token: 0x04000071 RID: 113
			public static string SHORT_JMP = "EB";

			// Token: 0x04000072 RID: 114
			public static string SHORT_JB = "72";

			// Token: 0x04000073 RID: 115
			public static string SHORT_JNB = "73";

			// Token: 0x04000074 RID: 116
			public static string SHORT_JZ = "74";

			// Token: 0x04000075 RID: 117
			public static string SHORT_JNZ = "75";

			// Token: 0x04000076 RID: 118
			public static string SHORT_JBE = "76";

			// Token: 0x04000077 RID: 119
			public static string SHORT_JA = "77";

			// Token: 0x04000078 RID: 120
			public static string LONG_JMP = "E9";

			// Token: 0x04000079 RID: 121
			public static string LONG_JB = "0F 82";

			// Token: 0x0400007A RID: 122
			public static string LONG_JNB = "0F 83";

			// Token: 0x0400007B RID: 123
			public static string LONG_JZ = "0F 84";

			// Token: 0x0400007C RID: 124
			public static string LONG_JNZ = "0F 85";

			// Token: 0x0400007D RID: 125
			public static string LONG_JBE = "0F 86";

			// Token: 0x0400007E RID: 126
			public static string LONG_JA = "0F 87";

			// Token: 0x0400007F RID: 127
			public static List<string> calls_only_avoid;
		}

		// Token: 0x0200001C RID: 28
		public class subroutine
		{
			// Token: 0x06000068 RID: 104 RVA: 0x00006AE1 File Offset: 0x00004CE1
			public subroutine()
			{
				this.name = "sub_xxxxxx";
				this.size = 0;
				this.stack_ret = 0;
				this.start = mem.PZERO;
				this.end = mem.PZERO;
			}

			// Token: 0x06000069 RID: 105 RVA: 0x00006B1C File Offset: 0x00004D1C
			public subroutine(IntPtr address)
			{
				this.name = "sub_" + convert.to_str(address);
				this.start = sasm.nextprologue(address, direction.BEHIND);
				this.end = sasm.nextprologue(this.start + 1, direction.AHEAD);
				this.stack_ret = (int)sasm.fretn(this.end);
				this.size = (int)this.end - (int)this.start;
			}

			// Token: 0x04000080 RID: 128
			public string name;

			// Token: 0x04000081 RID: 129
			public IntPtr start;

			// Token: 0x04000082 RID: 130
			public IntPtr end;

			// Token: 0x04000083 RID: 131
			public int size;

			// Token: 0x04000084 RID: 132
			public int stack_ret;
		}

		// Token: 0x0200001D RID: 29
		public static class reader
		{
			// Token: 0x0600006A RID: 106 RVA: 0x00006B9C File Offset: 0x00004D9C
			public static string sub(string str, int location, int len)
			{
				string text = "";
				bool flag = location + len > str.Length;
				string result;
				if (flag)
				{
					result = text;
				}
				else
				{
					for (int i = location; i < location + len; i++)
					{
						text += str[i].ToString();
					}
					result = text;
				}
				return result;
			}

			// Token: 0x0600006B RID: 107 RVA: 0x00006BF8 File Offset: 0x00004DF8
			public static bool checkstr(string str1, int location, string str2)
			{
				return sasm.reader.sub(str1, location, str2.Length) == str2;
			}

			// Token: 0x0600006C RID: 108 RVA: 0x00006C20 File Offset: 0x00004E20
			public static bool match(string strA, string strB)
			{
				return strA.IndexOf(strB) != -1;
			}

			// Token: 0x0600006D RID: 109 RVA: 0x00006C40 File Offset: 0x00004E40
			public static void INIT()
			{
				sasm.reader.REFERENCES = new List<opcode>();
				sasm.reader.REFERENCES.Add(new opcode("inc REG@1", "40"));
				sasm.reader.REFERENCES.Add(new opcode("push REG@1", "50"));
				sasm.reader.REFERENCES.Add(new opcode("pop REG@1", "58"));
				sasm.reader.REFERENCES.Add(new opcode("push IX bytes", "6A IX"));
				sasm.reader.REFERENCES.Add(new opcode("push value/offset:$xxyyzzww", "68 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("push dword from:xxyyzzww", "FF 35 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("push dword ptr[REG@2*SB]", "FF 70 SB"));
				sasm.reader.REFERENCES.Add(new opcode("retn YYXX", "C2 XX YY"));
				sasm.reader.REFERENCES.Add(new opcode("retn", "C3"));
				sasm.reader.REFERENCES.Add(new opcode("align 20", "CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC"));
				sasm.reader.REFERENCES.Add(new opcode("align 10", "CCCCCCCCCCCCCCCCCCCC"));
				sasm.reader.REFERENCES.Add(new opcode("align 10", "CCCCCCCCCCCCCCCCCC"));
				sasm.reader.REFERENCES.Add(new opcode("align 10", "CCCCCC"));
				sasm.reader.REFERENCES.Add(new opcode("endp", "CC"));
				sasm.reader.REFERENCES.Add(new opcode("jump *SI bytes", "EB SI"));
				sasm.reader.REFERENCES.Add(new opcode("jump *SI bytes if $CMPfl > $CMPv", "77 SI"));
				sasm.reader.REFERENCES.Add(new opcode("jump *SI bytes if $CMPfl <= $CMPv", "76 SI"));
				sasm.reader.REFERENCES.Add(new opcode("jump *SI bytes if $CMPfl != 0", "75 SI"));
				sasm.reader.REFERENCES.Add(new opcode("jump *SI bytes if $CMPfl == 0", "74 SI"));
				sasm.reader.REFERENCES.Add(new opcode("jump *SI bytes if $CMPfl >= $CMPv", "73 SI"));
				sasm.reader.REFERENCES.Add(new opcode("jump *SI bytes if $CMPfl < $CMPv", "72 SI"));
				sasm.reader.REFERENCES.Add(new opcode("jump to $xxyyzzww", "E9 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("jump to $xxyyzzww if $CMPfl > $CMPv", "0F 87 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("jump to $xxyyzzww if $CMPfl <= $CMPv", "0F 86 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("jump to $xxyyzzww if $CMPfl != 0", "0F 85 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("jump to $xxyyzzww if $CMPfl == 0", "0F 84 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("jump to $xxyyzzww if $CMPfl >= $CMPv", "0F 83 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("jump to $xxyyzzww if $CMPfl < $CMPv", "0F 82 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov large fs:xxyyzzww,esp", "64 89 25 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov REG@1,*xxyyzzww", "B8 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov dword:xxyyzzww,WWZZYYXX", "C7 05 xx yy zz ww WW ZZ YY XX"));
				sasm.reader.REFERENCES.Add(new opcode("mov al,[REG@2]", "8A 00"));
				sasm.reader.REFERENCES.Add(new opcode("mov dword ptr[REG@2],offset:xxyyzzww", "C7 00 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov dword ptr[REG@2*SB],offset:xxyyzzww", "C7 40 SB xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov dword ptr[REG@2],xxyyzzww", "C7 00 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov byte ptr[REG@2],XX", "C6 00 XX"));
				sasm.reader.REFERENCES.Add(new opcode("mov byte ptr[REG@2*SB],XX", "C6 40 SB XX"));
				sasm.reader.REFERENCES.Add(new opcode("mov byte ptr[REG@3+eax],XX", "C6 04 00 XX"));
				sasm.reader.REFERENCES.Add(new opcode("mov byte ptr[REG@3+ecx],XX", "C6 04 08 XX"));
				sasm.reader.REFERENCES.Add(new opcode("mov byte ptr[REG@3+edx],XX", "C6 04 10 XX"));
				sasm.reader.REFERENCES.Add(new opcode("mov byte ptr[REG@3+ebx],XX", "C6 04 18 XX"));
				sasm.reader.REFERENCES.Add(new opcode("mov byte ptr[REG@3+esp],XX", "C6 04 20 XX"));
				sasm.reader.REFERENCES.Add(new opcode("mov byte ptr[REG@3+ebp],XX", "C6 04 28 XX"));
				sasm.reader.REFERENCES.Add(new opcode("mov byte ptr[REG@3+esi],XX", "C6 04 30 XX"));
				sasm.reader.REFERENCES.Add(new opcode("mov byte ptr[REG@3+edi],XX", "C6 04 38 XX"));
				sasm.reader.REFERENCES.Add(new opcode("movzx eax,word ptr[REG@3+xxyyzzww]", "0F B7 80 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("movzx ecx,word ptr[REG@3+xxyyzzww]", "0F B7 88 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("movzx edx,word ptr[REG@3+xxyyzzww]", "0F B7 90 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("movzx ebx,word ptr[REG@3+xxyyzzww]", "0F B7 98 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("movzx esp,word ptr[REG@3+xxyyzzww]", "0F B7 A0 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("movzx ebp,word ptr[REG@3+xxyyzzww]", "0F B7 A8 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("movzx esi,word ptr[REG@3+xxyyzzww]", "0F B7 B0 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("movzx edi,word ptr[REG@3+xxyyzzww]", "0F B7 B8 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov eax,REG@2", "8B C0"));
				sasm.reader.REFERENCES.Add(new opcode("mov ecx,REG@2", "8B C8"));
				sasm.reader.REFERENCES.Add(new opcode("mov edx,REG@2", "8B D0"));
				sasm.reader.REFERENCES.Add(new opcode("mov ebx,REG@2", "8B D8"));
				sasm.reader.REFERENCES.Add(new opcode("mov esp,REG@2", "8B E0"));
				sasm.reader.REFERENCES.Add(new opcode("mov ebp,REG@2", "8B E8"));
				sasm.reader.REFERENCES.Add(new opcode("mov esi,REG@2", "8B F0"));
				sasm.reader.REFERENCES.Add(new opcode("mov edi,REG@2", "8B F8"));
				sasm.reader.REFERENCES.Add(new opcode("mov eax,[REG@2]", "8B 00"));
				sasm.reader.REFERENCES.Add(new opcode("mov ecx,[REG@2]", "8B 08"));
				sasm.reader.REFERENCES.Add(new opcode("mov edx,[REG@2]", "8B 10"));
				sasm.reader.REFERENCES.Add(new opcode("mov ebx,[REG@2]", "8B 18"));
				sasm.reader.REFERENCES.Add(new opcode("mov esp,[REG@2]", "8B 20"));
				sasm.reader.REFERENCES.Add(new opcode("mov ebp,[REG@2]", "8B 28"));
				sasm.reader.REFERENCES.Add(new opcode("mov esi,[REG@2]", "8B 30"));
				sasm.reader.REFERENCES.Add(new opcode("mov edi,[REG@2]", "8B 38"));
				sasm.reader.REFERENCES.Add(new opcode("mov eax,[REG@2*SB]", "8B 40 SB"));
				sasm.reader.REFERENCES.Add(new opcode("mov ecx,[REG@2*SB]", "8B 48 SB"));
				sasm.reader.REFERENCES.Add(new opcode("mov edx,[REG@2*SB]", "8B 50 SB"));
				sasm.reader.REFERENCES.Add(new opcode("mov ebx,[REG@2*SB]", "8B 58 SB"));
				sasm.reader.REFERENCES.Add(new opcode("mov esp,[REG@2*SB]", "8B 60 SB"));
				sasm.reader.REFERENCES.Add(new opcode("mov ebp,[REG@2*SB]", "8B 68 SB"));
				sasm.reader.REFERENCES.Add(new opcode("mov esi,[REG@2*SB]", "8B 70 SB"));
				sasm.reader.REFERENCES.Add(new opcode("mov edi,[REG@2*SB]", "8B 78 SB"));
				sasm.reader.REFERENCES.Add(new opcode("mov [REG@2*SB],eax", "89 40 SB"));
				sasm.reader.REFERENCES.Add(new opcode("mov [REG@2*SB],ecx", "89 48 SB"));
				sasm.reader.REFERENCES.Add(new opcode("mov [REG@2*SB],edx", "89 50 SB"));
				sasm.reader.REFERENCES.Add(new opcode("mov [REG@2*SB],ebx", "89 58 SB"));
				sasm.reader.REFERENCES.Add(new opcode("mov [REG@2*SB],esp", "89 60 SB"));
				sasm.reader.REFERENCES.Add(new opcode("mov [REG@2*SB],ebp", "89 68 SB"));
				sasm.reader.REFERENCES.Add(new opcode("mov [REG@2*SB],esi", "89 70 SB"));
				sasm.reader.REFERENCES.Add(new opcode("mov [REG@2*SB],edi", "89 78 SB"));
				sasm.reader.REFERENCES.Add(new opcode("mov [REG@2+xxyyzzww],eax", "89 80 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov [REG@2+xxyyzzww],ecx", "89 88 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov [REG@2+xxyyzzww],edx", "89 90 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov [REG@2+xxyyzzww],ebx", "89 98 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov [REG@2+xxyyzzww],esp", "89 A0 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov [REG@2+xxyyzzww],ebp", "89 A8 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov [REG@2+xxyyzzww],esi", "89 B0 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov [REG@2+xxyyzzww],edi", "89 B8 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov eax,[REG@2*xxyyzzww]", "8B 80 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov ecx,[REG@2*xxyyzzww]", "8B 88 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov edx,[REG@2*xxyyzzww]", "8B 90 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov ebx,[REG@2*xxyyzzww]", "8B 98 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov esp,[REG@2*xxyyzzww]", "8B A0 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov ebp,[REG@2*xxyyzzww]", "8B A8 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov esi,[REG@2*xxyyzzww]", "8B B0 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov edi,[REG@2*xxyyzzww]", "8B B8 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov eax,dword:xxyyzzww", "A1 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov ecx,dword:xxyyzzww", "8B 0D xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov edx,dword:xxyyzzww", "8B 15 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov ebx,dword:xxyyzzww", "8B 1D xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov esp,dword:xxyyzzww", "8B 25 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov ebp,dword:xxyyzzww", "8B 2D xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov esi,dword:xxyyzzww", "8B 35 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov edi,dword:xxyyzzww", "8B 3D xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov dword:xxyyzzww,eax", "A3 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov dword:xxyyzzww,ecx", "89 0D xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov dword:xxyyzzww,edx", "89 15 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov dword:xxyyzzww,ebx", "89 1D xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov dword:xxyyzzww,esp", "89 25 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov dword:xxyyzzww,ebp", "89 2D xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov dword:xxyyzzww,esi", "89 35 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("mov dword:xxyyzzww,edi", "89 3D xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("cmovx eax,REG@3", "0F 44 C0"));
				sasm.reader.REFERENCES.Add(new opcode("cmovx ecx,REG@3", "0F 44 C8"));
				sasm.reader.REFERENCES.Add(new opcode("cmovx edx,REG@3", "0F 44 D0"));
				sasm.reader.REFERENCES.Add(new opcode("cmovx ebx,REG@3", "0F 44 D8"));
				sasm.reader.REFERENCES.Add(new opcode("cmovx esp,REG@3", "0F 44 E0"));
				sasm.reader.REFERENCES.Add(new opcode("cmovx ebp,REG@3", "0F 44 E8"));
				sasm.reader.REFERENCES.Add(new opcode("cmovx esi,REG@3", "0F 44 F0"));
				sasm.reader.REFERENCES.Add(new opcode("cmovx edi,REG@3", "0F 44 F8"));
				sasm.reader.REFERENCES.Add(new opcode("cmova eax,REG@3", "0F 47 C0"));
				sasm.reader.REFERENCES.Add(new opcode("cmova ecx,REG@3", "0F 47 C8"));
				sasm.reader.REFERENCES.Add(new opcode("cmova edx,REG@3", "0F 47 D0"));
				sasm.reader.REFERENCES.Add(new opcode("cmova ebx,REG@3", "0F 47 D8"));
				sasm.reader.REFERENCES.Add(new opcode("cmova esp,REG@3", "0F 47 E0"));
				sasm.reader.REFERENCES.Add(new opcode("cmova ebp,REG@3", "0F 47 E8"));
				sasm.reader.REFERENCES.Add(new opcode("cmova esi,REG@3", "0F 47 F0"));
				sasm.reader.REFERENCES.Add(new opcode("cmova edi,REG@3", "0F 47 F8"));
				sasm.reader.REFERENCES.Add(new opcode("cmovnz eax,REG@3", "0F 45 C0"));
				sasm.reader.REFERENCES.Add(new opcode("cmovnz ecx,REG@3", "0F 45 C8"));
				sasm.reader.REFERENCES.Add(new opcode("cmovnz edx,REG@3", "0F 45 D0"));
				sasm.reader.REFERENCES.Add(new opcode("cmovnz ebx,REG@3", "0F 45 D8"));
				sasm.reader.REFERENCES.Add(new opcode("cmovnz esp,REG@3", "0F 45 E0"));
				sasm.reader.REFERENCES.Add(new opcode("cmovnz ebp,REG@3", "0F 45 E8"));
				sasm.reader.REFERENCES.Add(new opcode("cmovnz esi,REG@3", "0F 45 F0"));
				sasm.reader.REFERENCES.Add(new opcode("cmovnz edi,REG@3", "0F 45 F8"));
				sasm.reader.REFERENCES.Add(new opcode("cmovbe eax,[REG@3*SB]", "0F 46 40 SB"));
				sasm.reader.REFERENCES.Add(new opcode("cmovbe ecx,[REG@3*SB]", "0F 46 48 SB"));
				sasm.reader.REFERENCES.Add(new opcode("cmovbe edx,[REG@3*SB]", "0F 46 50 SB"));
				sasm.reader.REFERENCES.Add(new opcode("cmovbe ebx,[REG@3*SB]", "0F 46 58 SB"));
				sasm.reader.REFERENCES.Add(new opcode("cmovbe esp,[REG@3*SB]", "0F 46 60 SB"));
				sasm.reader.REFERENCES.Add(new opcode("cmovbe ebp,[REG@3*SB]", "0F 46 68 SB"));
				sasm.reader.REFERENCES.Add(new opcode("cmovbe esi,[REG@3*SB]", "0F 46 70 SB"));
				sasm.reader.REFERENCES.Add(new opcode("cmovbe edi,[REG@3*SB]", "0F 46 78 SB"));
				sasm.reader.REFERENCES.Add(new opcode("lea eax,[REG@2*SB]", "8D 40 SB"));
				sasm.reader.REFERENCES.Add(new opcode("lea ecx,[REG@2*SB]", "8D 48 SB"));
				sasm.reader.REFERENCES.Add(new opcode("lea edx,[REG@2*SB]", "8D 50 SB"));
				sasm.reader.REFERENCES.Add(new opcode("lea ebx,[REG@2*SB]", "8D 58 SB"));
				sasm.reader.REFERENCES.Add(new opcode("lea esp,[REG@2*SB]", "8D 60 SB"));
				sasm.reader.REFERENCES.Add(new opcode("lea ebp,[REG@2*SB]", "8D 68 SB"));
				sasm.reader.REFERENCES.Add(new opcode("lea esi,[REG@2*SB]", "8D 70 SB"));
				sasm.reader.REFERENCES.Add(new opcode("lea edi,[REG@2*SB]", "8D 78 SB"));
				sasm.reader.REFERENCES.Add(new opcode("lea eax,[REG@2*xxyyzzww]", "8D 80 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("lea ecx,[REG@2*xxyyzzww]", "8D 88 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("lea edx,[REG@2*xxyyzzww]", "8D 90 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("lea ebx,[REG@2*xxyyzzww]", "8D 98 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("lea esp,[REG@2*xxyyzzww]", "8D A0 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("lea ebp,[REG@2*xxyyzzww]", "8D A8 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("lea esi,[REG@2*xxyyzzww]", "8D B0 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("lea edi,[REG@2*xxyyzzww]", "8D B8 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("lea eax,[REG@3+eax]", "8D 04 00"));
				sasm.reader.REFERENCES.Add(new opcode("lea eax,[REG@3+ecx]", "8D 04 08"));
				sasm.reader.REFERENCES.Add(new opcode("lea eax,[REG@3+edx]", "8D 04 10"));
				sasm.reader.REFERENCES.Add(new opcode("lea eax,[REG@3+ebx]", "8D 04 18"));
				sasm.reader.REFERENCES.Add(new opcode("lea eax,[REG@3+esp]", "8D 04 20"));
				sasm.reader.REFERENCES.Add(new opcode("lea eax,[REG@3+ebp]", "8D 04 28"));
				sasm.reader.REFERENCES.Add(new opcode("lea eax,[REG@3+esi]", "8D 04 30"));
				sasm.reader.REFERENCES.Add(new opcode("lea eax,[REG@3+edi]", "8D 04 38"));
				sasm.reader.REFERENCES.Add(new opcode("lea eax,xxyyzzww[eax*8]", "8D 04 C5 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("lea eax,xxyyzzww[ecx*8]", "8D 04 CD xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("or dword:xxyyzzww,WWZZYYXX", "81 0D xx yy zz ww WW ZZ YY XX"));
				sasm.reader.REFERENCES.Add(new opcode("or REG@2,xxyyzzww", "83 C8 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("xor eax,REG@2", "33 C0"));
				sasm.reader.REFERENCES.Add(new opcode("xor ecx,REG@2", "33 C8"));
				sasm.reader.REFERENCES.Add(new opcode("xor edx,REG@2", "33 D0"));
				sasm.reader.REFERENCES.Add(new opcode("xor ebx,REG@2", "33 D8"));
				sasm.reader.REFERENCES.Add(new opcode("xor esp,REG@2", "33 E0"));
				sasm.reader.REFERENCES.Add(new opcode("xor ebp,REG@2", "33 E8"));
				sasm.reader.REFERENCES.Add(new opcode("xor esi,REG@2", "33 F0"));
				sasm.reader.REFERENCES.Add(new opcode("xor edi,REG@2", "33 F8"));
				sasm.reader.REFERENCES.Add(new opcode("add REG@2,XX", "83 C0 XX"));
				sasm.reader.REFERENCES.Add(new opcode("add eax,REG@2", "03 C0"));
				sasm.reader.REFERENCES.Add(new opcode("add ecx,REG@2", "03 C8"));
				sasm.reader.REFERENCES.Add(new opcode("add edx,REG@2", "03 D0"));
				sasm.reader.REFERENCES.Add(new opcode("add ebx,REG@2", "03 D8"));
				sasm.reader.REFERENCES.Add(new opcode("add esp,REG@2", "03 E0"));
				sasm.reader.REFERENCES.Add(new opcode("add ebp,REG@2", "03 E8"));
				sasm.reader.REFERENCES.Add(new opcode("add esi,REG@2", "03 F0"));
				sasm.reader.REFERENCES.Add(new opcode("add edi,REG@2", "03 F8"));
				sasm.reader.REFERENCES.Add(new opcode("add dword ptr[REG@2*SB],XX", "83 40 SB XX"));
				sasm.reader.REFERENCES.Add(new opcode("sub eax,REG@2", "2B C0"));
				sasm.reader.REFERENCES.Add(new opcode("sub ecx,REG@2", "2B C8"));
				sasm.reader.REFERENCES.Add(new opcode("sub edx,REG@2", "2B D0"));
				sasm.reader.REFERENCES.Add(new opcode("sub ebx,REG@2", "2B D8"));
				sasm.reader.REFERENCES.Add(new opcode("sub esp,REG@2", "2B E0"));
				sasm.reader.REFERENCES.Add(new opcode("sub ebp,REG@2", "2B E8"));
				sasm.reader.REFERENCES.Add(new opcode("sub esi,REG@2", "2B F0"));
				sasm.reader.REFERENCES.Add(new opcode("sub edi,REG@2", "2B F8"));
				sasm.reader.REFERENCES.Add(new opcode("sub REG@2,xxyyzzww", "81 E8 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("sub REG@2,XX", "83 E8 XX"));
				sasm.reader.REFERENCES.Add(new opcode("cmp eax,REG@2", "3B C0"));
				sasm.reader.REFERENCES.Add(new opcode("cmp ecx,REG@2", "3B C8"));
				sasm.reader.REFERENCES.Add(new opcode("cmp edx,REG@2", "3B D0"));
				sasm.reader.REFERENCES.Add(new opcode("cmp ebx,REG@2", "3B D8"));
				sasm.reader.REFERENCES.Add(new opcode("cmp esp,REG@2", "3B E0"));
				sasm.reader.REFERENCES.Add(new opcode("cmp ebp,REG@2", "3B E8"));
				sasm.reader.REFERENCES.Add(new opcode("cmp esi,REG@2", "3B F0"));
				sasm.reader.REFERENCES.Add(new opcode("cmp edi,REG@2", "3B F8"));
				sasm.reader.REFERENCES.Add(new opcode("cmp dword ptr[REG@2*SB],XX", "83 70 SB XX"));
				sasm.reader.REFERENCES.Add(new opcode("cmp REG@2,XX", "83 F8 XX"));
				sasm.reader.REFERENCES.Add(new opcode("cmp byte ptr[REG@2],XX", "80 38 XX"));
				sasm.reader.REFERENCES.Add(new opcode("cmp ecx,offset:xxyyzzww", "3B 0D xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("cmp edx,offset:xxyyzzww", "3B 15 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("cmp ebx,offset:xxyyzzww", "3B 1D xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("cmp esp,offset:xxyyzzww", "3B 25 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("cmp ebp,offset:xxyyzzww", "3B 2D xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("cmp esi,offset:xxyyzzww", "3B 35 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("cmp edi,offset:xxyyzzww", "3B 3D xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("test al,al", "84 C0"));
				sasm.reader.REFERENCES.Add(new opcode("test eax,REG@2", "85 C0"));
				sasm.reader.REFERENCES.Add(new opcode("test ecx,REG@2", "85 C8"));
				sasm.reader.REFERENCES.Add(new opcode("test edx,REG@2", "85 D0"));
				sasm.reader.REFERENCES.Add(new opcode("test ebx,REG@2", "85 D8"));
				sasm.reader.REFERENCES.Add(new opcode("test esp,REG@2", "85 E0"));
				sasm.reader.REFERENCES.Add(new opcode("test ebp,REG@2", "85 E8"));
				sasm.reader.REFERENCES.Add(new opcode("test esi,REG@2", "85 F0"));
				sasm.reader.REFERENCES.Add(new opcode("test edi,REG@2", "85 F8"));
				sasm.reader.REFERENCES.Add(new opcode("lock inc dword:xxyyzzww", "F0 FF 05 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("call ds-offset:$xxyyzzww", "FF 15 xx yy zz ww"));
				sasm.reader.REFERENCES.Add(new opcode("call $xxyyzzww", "E8 xx yy zz ww"));
			}

			// Token: 0x0600006E RID: 110 RVA: 0x00008438 File Offset: 0x00006638
			public static opcode read(IntPtr address)
			{
				new opcode();
				List<opcode> references = sasm.reader.REFERENCES;
				string newValue = "cmp flag";
				string newValue2 = "";
				opcode opcode = new opcode();
				for (int i = 0; i < references.Count; i++)
				{
					cbyte cbyte = new cbyte(mem.sreadb(address, references[i].size));
					string text = references[i].bytecode.Replace(" ", "");
					string text2 = references[i].asm;
					opcode.address = address;
					byte b = 0;
					byte b2 = 0;
					byte b3 = 0;
					byte b4 = 0;
					byte b5 = 0;
					byte b6 = 0;
					byte b7 = 0;
					byte b8 = 0;
					int value = 0;
					int value2 = 0;
					string newValue3 = "x??";
					string text3 = "?";
					char[] array = text.Replace(" ", "").ToCharArray();
					for (int j = 0; j < references[i].size; j++)
					{
						string text4 = text.Substring(j * 2, 2);
						char c = convert.to_str(cbyte.at(j), false)[0];
						char c2 = convert.to_str(cbyte.at(j), false)[1];
						string text5 = convert.to_str(cbyte.at(j), false);
						bool flag = text4 == "XX" || text4 == "YY" || text4 == "ZZ" || text4 == "WW" || text4 == "xx" || text4 == "yy" || text4 == "zz" || text4 == "ww" || text4 == "SB" || text4 == "IX" || text4 == "SI";
						if (flag)
						{
							bool flag2 = text4 == "XX";
							if (flag2)
							{
								b = cbyte.at(j);
							}
							bool flag3 = text4 == "YY";
							if (flag3)
							{
								b2 = cbyte.at(j);
							}
							bool flag4 = text4 == "ZZ";
							if (flag4)
							{
								b3 = cbyte.at(j);
							}
							bool flag5 = text4 == "WW";
							if (flag5)
							{
								b4 = cbyte.at(j);
							}
							bool flag6 = text4 == "xx";
							if (flag6)
							{
								b5 = cbyte.at(j);
							}
							bool flag7 = text4 == "yy";
							if (flag7)
							{
								b6 = cbyte.at(j);
							}
							bool flag8 = text4 == "zz";
							if (flag8)
							{
								b7 = cbyte.at(j);
							}
							bool flag9 = text4 == "ww";
							if (flag9)
							{
								b8 = cbyte.at(j);
							}
							bool flag10 = text4 == "IX";
							if (flag10)
							{
								value = (int)cbyte.at(j);
							}
							bool flag11 = text4 == "SB";
							if (flag11)
							{
								byte b9 = cbyte.at(j);
								bool flag12 = b9 >= 128;
								if (flag12)
								{
									newValue3 = "-" + convert.to_str((byte)(256 - (int)b9), false);
								}
								else
								{
									newValue3 = "+" + convert.to_str(b9, false);
								}
							}
							bool flag13 = text4 == "SI";
							if (flag13)
							{
								byte b10 = cbyte.at(j);
								bool flag14 = b10 >= 128;
								if (flag14)
								{
									value2 = -(256 - (int)b10);
								}
								else
								{
									value2 = (int)b10;
								}
							}
							array[j * 2] = text5[0];
							array[j * 2 + 1] = text5[1];
						}
						bool flag15 = text2.Contains("REG@1") && j == 0;
						bool flag16 = text2.Contains("REG@2") && j == 1;
						bool flag17 = text2.Contains("REG@3") && j == 2;
						bool flag18 = flag15 || flag16 || flag17;
						if (flag18)
						{
							byte b11 = convert.to_hex(text4);
							bool flag19 = b11 == cbyte.at(j);
							if (flag19)
							{
								text3 = "eax";
							}
							else
							{
								bool flag20 = b11 + 1 == cbyte.at(j);
								if (flag20)
								{
									text3 = "ecx";
								}
								else
								{
									bool flag21 = b11 + 2 == cbyte.at(j);
									if (flag21)
									{
										text3 = "edx";
									}
									else
									{
										bool flag22 = b11 + 3 == cbyte.at(j);
										if (flag22)
										{
											text3 = "ebx";
										}
										else
										{
											bool flag23 = b11 + 4 == cbyte.at(j);
											if (flag23)
											{
												text3 = "esp";
											}
											else
											{
												bool flag24 = b11 + 5 == cbyte.at(j);
												if (flag24)
												{
													text3 = "ebp";
												}
												else
												{
													bool flag25 = b11 + 6 == cbyte.at(j);
													if (flag25)
													{
														text3 = "esi";
													}
													else
													{
														bool flag26 = b11 + 7 == cbyte.at(j);
														if (flag26)
														{
															text3 = "edi";
														}
													}
												}
											}
										}
									}
								}
							}
							bool flag27 = text3 != "?";
							if (flag27)
							{
								array[j * 2] = text5[0];
								array[j * 2 + 1] = text5[1];
							}
						}
					}
					bool flag28 = cbyte.size() == 2;
					if (flag28)
					{
						bool flag29 = cbyte.at(0) == 59 || cbyte.at(0) == 133;
						if (flag29)
						{
							string text6 = "";
							string text7 = "";
							byte b12 = cbyte.at(1);
							for (int k = 0; k < 8; k++)
							{
								bool flag30 = k == 0;
								if (flag30)
								{
									text6 = "eax";
								}
								else
								{
									bool flag31 = k == 1;
									if (flag31)
									{
										text6 = "ecx";
									}
									else
									{
										bool flag32 = k == 2;
										if (flag32)
										{
											text6 = "edx";
										}
										else
										{
											bool flag33 = k == 3;
											if (flag33)
											{
												text6 = "ebx";
											}
											else
											{
												bool flag34 = k == 4;
												if (flag34)
												{
													text6 = "esp";
												}
												else
												{
													bool flag35 = k == 5;
													if (flag35)
													{
														text6 = "ebp";
													}
													else
													{
														bool flag36 = k == 6;
														if (flag36)
														{
															text6 = "esi";
														}
														else
														{
															bool flag37 = k == 7;
															if (flag37)
															{
																text6 = "edi";
															}
														}
													}
												}
											}
										}
									}
								}
								bool flag38 = (int)b12 == 192 + k * 8;
								if (flag38)
								{
									text7 = "eax";
								}
								bool flag39 = (int)b12 == 192 + k * 8 + 1;
								if (flag39)
								{
									text7 = "ecx";
								}
								bool flag40 = (int)b12 == 192 + k * 8 + 2;
								if (flag40)
								{
									text7 = "edx";
								}
								bool flag41 = (int)b12 == 192 + k * 8 + 3;
								if (flag41)
								{
									text7 = "ebx";
								}
								bool flag42 = (int)b12 == 192 + k * 8 + 4;
								if (flag42)
								{
									text7 = "esp";
								}
								bool flag43 = (int)b12 == 192 + k * 8 + 5;
								if (flag43)
								{
									text7 = "ebp";
								}
								bool flag44 = (int)b12 == 192 + k * 8 + 6;
								if (flag44)
								{
									text7 = "esi";
								}
								bool flag45 = (int)b12 == 192 + k * 8 + 7;
								if (flag45)
								{
									text7 = "edi";
								}
								bool flag46 = text7 != "" && text6 != "";
								if (flag46)
								{
									break;
								}
							}
							newValue = text6;
							newValue2 = text7;
						}
					}
					else
					{
						bool flag47 = cbyte.size() == 3 && cbyte.at(0) == 131;
						if (flag47)
						{
							string text8 = "";
							byte b13 = cbyte.at(1);
							bool flag48 = b13 == 248;
							if (flag48)
							{
								text8 = "eax";
							}
							bool flag49 = b13 == 249;
							if (flag49)
							{
								text8 = "ecx";
							}
							bool flag50 = b13 == 250;
							if (flag50)
							{
								text8 = "edx";
							}
							bool flag51 = b13 == 251;
							if (flag51)
							{
								text8 = "ebx";
							}
							bool flag52 = b13 == 252;
							if (flag52)
							{
								text8 = "esp";
							}
							bool flag53 = b13 == 253;
							if (flag53)
							{
								text8 = "ebp";
							}
							bool flag54 = b13 == 254;
							if (flag54)
							{
								text8 = "esi";
							}
							bool flag55 = b13 == byte.MaxValue;
							if (flag55)
							{
								text8 = "edi";
							}
							newValue = text8;
							newValue2 = Convert.ToString((int)cbyte.at(2));
						}
					}
					text = new string(array);
					bool flag56 = cbyte.compare(new cbyte(text));
					if (flag56)
					{
						text2 = text2.Replace("$CMPfl", newValue);
						text2 = text2.Replace("$CMPv", newValue2);
						bool flag57 = text2.Contains("$xxyyzzww");
						if (flag57)
						{
							string str = convert.to_str(b8, false);
							string str2 = convert.to_str(b7, false);
							string str3 = convert.to_str(b6, false);
							string str4 = convert.to_str(b5, false);
							IntPtr intPtr = convert.to_addr(str + str2 + str3 + str4);
							bool flag58 = (int)intPtr > (int)mem.BASE && (int)intPtr < 268435455;
							if (flag58)
							{
								text2 = text2.Replace("$xxyyzzww", convert.to_str(intPtr));
							}
							else
							{
								int offset = convert.to_int(b5, b6, b7, b8);
								string newValue4 = convert.to_str(address + 5 + offset);
								text2 = text2.Replace("$xxyyzzww", newValue4);
							}
						}
						else
						{
							bool flag59 = text2.Contains("*xxyyzzww");
							if (flag59)
							{
								convert.to_str(b8, false);
								convert.to_str(b7, false);
								convert.to_str(b6, false);
								convert.to_str(b5, false);
								int num = convert.to_int(b5, b6, b7, b8);
								bool flag60 = num < 0;
								string text9;
								if (flag60)
								{
									text9 = "-";
								}
								else
								{
									text9 = "+";
								}
								text9 += convert.to_str((IntPtr)Math.Abs(num));
								text2 = text2.Replace("*xxyyzzww", text9);
							}
						}
						text2 = text2.Replace("IX", Convert.ToString(value));
						text2 = text2.Replace("XX", convert.to_str(b, false));
						text2 = text2.Replace("YY", convert.to_str(b2, false));
						text2 = text2.Replace("ZZ", convert.to_str(b3, false));
						text2 = text2.Replace("WW", convert.to_str(b4, false));
						text2 = text2.Replace("xx", convert.to_str(b8, false));
						text2 = text2.Replace("yy", convert.to_str(b7, false));
						text2 = text2.Replace("zz", convert.to_str(b6, false));
						text2 = text2.Replace("ww", convert.to_str(b5, false));
						text2 = text2.Replace("*SB", newValue3);
						text2 = text2.Replace("*SI", Convert.ToString(value2));
						text2 = text2.Replace("REG@1", text3);
						text2 = text2.Replace("REG@2", text3);
						text2 = text2.Replace("REG@3", text3);
						opcode.asm = text2;
						opcode.bytecode = cbyte.to_string();
						opcode.size = references[i].size;
						break;
					}
				}
				return opcode;
			}

			// Token: 0x0600006F RID: 111 RVA: 0x00008FFC File Offset: 0x000071FC
			public static List<opcode> read(IntPtr address, IntPtr to)
			{
				List<opcode> list = new List<opcode>();
				int i = (int)address;
				int num = (int)to;
				while (i < num)
				{
					opcode opcode = sasm.reader.read((IntPtr)i);
					list.Add(opcode);
					i += opcode.size;
				}
				return list;
			}

			// Token: 0x06000070 RID: 112 RVA: 0x00009050 File Offset: 0x00007250
			public static string sread(sasm.subroutine func)
			{
				string text = "";
				opcode opcode;
				for (int i = 0; i < func.size + 1; i += opcode.size)
				{
					opcode = sasm.reader.read(func.start + i);
					text += opcode.asm;
					text += " \n";
				}
				return text;
			}

			// Token: 0x04000085 RID: 133
			public static List<opcode> REFERENCES;
		}

		// Token: 0x0200001E RID: 30
		public static class scanning
		{
			// Token: 0x06000071 RID: 113 RVA: 0x000090B4 File Offset: 0x000072B4
			private static void checkbytes(RESULTS results, IntPtr location, long bsize, byte[] search_in, IntPtr func)
			{
				int num = 0;
				int num2 = 5;
				while ((long)num < bsize - (long)num2 && results.Count < 2000000)
				{
					IntPtr intPtr = location + num;
					bool flag = search_in[num] == 232 && intPtr + mem.readi(intPtr + 1) + 5 == func;
					if (flag)
					{
						results.Add(intPtr);
					}
					num++;
				}
			}

			// Token: 0x06000072 RID: 114 RVA: 0x00009130 File Offset: 0x00007330
			public static RESULTS scancall(IntPtr from, IntPtr to, IntPtr sub)
			{
				RESULTS results = new RESULTS();
				int i = (int)from;
				int num = (int)to;
				int num2 = 5;
				while (i < num)
				{
					int num3 = 0;
					byte[] array = new byte[262144];
					bool flag = functions.ReadProcessMemory(mem.PROC, (IntPtr)i, array, array.Length, ref num3);
					if (flag)
					{
						sasm.scanning.checkbytes(results, (IntPtr)i, (long)array.Length, array, sub);
					}
					i += array.Length - (num2 - 1);
				}
				return results;
			}

			// Token: 0x06000073 RID: 115 RVA: 0x000091B8 File Offset: 0x000073B8
			private static IntPtr checkbytes(int location, byte[] search_in, cbyte scan_bytes, string mask, mem.comparisons cmps)
			{
				for (int i = 0; i < search_in.Length - mask.Length; i++)
				{
					int num = location + i;
					bool flag = true;
					for (int j = 0; j < scan_bytes.size(); j++)
					{
						bool flag2 = mask[j] != 'x' && mask[j] == '.' && search_in[i + j] != scan_bytes.at(j);
						if (flag2)
						{
							flag = false;
						}
					}
					bool flag3 = flag;
					if (flag3)
					{
						for (int k = 0; k < cmps.LIST.Count; k++)
						{
							cmpdata cmpdata = cmps.LIST[k];
							int count = cmpdata.bytes_cmp.Length / 2;
							bool flag4 = cmpdata.type == comparison_type.OFFSET_EQUAL_TO && !(cmpdata.bytes_cmp == mem.sreadb((IntPtr)(num + cmpdata.offset), count).Replace(" ", ""));
							if (flag4)
							{
								flag = false;
								break;
							}
							bool flag5 = cmpdata.type == comparison_type.OFFSET_NOT_EQUAL_TO && cmpdata.bytes_cmp == mem.sreadb((IntPtr)(num + cmpdata.offset), count).Replace(" ", "");
							if (flag5)
							{
								flag = false;
								break;
							}
							bool flag6 = cmpdata.type == comparison_type.OFFSET_PTR_OFFSET_EQUAL_TO && !(cmpdata.bytes_cmp == mem.sreadb((IntPtr)(num + cmpdata.offset), count).Replace(" ", ""));
							if (flag6)
							{
								flag = false;
								break;
							}
							bool flag7 = cmpdata.type == comparison_type.OFFSET_PTR_OFFSET_NOT_EQUAL_TO && cmpdata.bytes_cmp == mem.sreadb((IntPtr)(num + cmpdata.offset), count).Replace(" ", "");
							if (flag7)
							{
								flag = false;
								break;
							}
						}
						bool flag8 = flag;
						if (flag8)
						{
							return (IntPtr)num;
						}
					}
				}
				return mem.PZERO;
			}

			// Token: 0x06000074 RID: 116 RVA: 0x000093DC File Offset: 0x000075DC
			private static void checkbytes(ref RESULTS results, int location, byte[] search_in, cbyte scan_bytes, string mask)
			{
				for (int i = 0; i < search_in.Length - mask.Length; i++)
				{
					bool flag = true;
					for (int j = 0; j < scan_bytes.size(); j++)
					{
						bool flag2 = mask[j] != 'x' && mask[j] == '.' && search_in[i + j] != scan_bytes.at(j);
						if (flag2)
						{
							flag = false;
						}
					}
					bool flag3 = flag;
					if (flag3)
					{
						results.Add((IntPtr)(location + i));
					}
				}
			}

			// Token: 0x06000075 RID: 117 RVA: 0x00009474 File Offset: 0x00007674
			public static IntPtr scan(IntPtr start, IntPtr end, string array_of_bytes, string mask, mem.comparisons cdata)
			{
				IntPtr intPtr = mem.PZERO;
				int i = (int)start;
				int num = (int)end;
				cbyte cbyte = new cbyte(array_of_bytes);
				while (i < num)
				{
					int default_BUFFER = mem.DEFAULT_BUFFER;
					int num2 = 0;
					byte[] array = new byte[default_BUFFER];
					bool flag = functions.ReadProcessMemory(mem.PROC, (IntPtr)i, array, default_BUFFER, ref num2);
					if (flag)
					{
						intPtr = sasm.scanning.checkbytes(i, array, cbyte, mask, cdata);
					}
					bool flag2 = intPtr != mem.PZERO;
					if (flag2)
					{
						break;
					}
					i += default_BUFFER - cbyte.size();
				}
				return intPtr;
			}

			// Token: 0x06000076 RID: 118 RVA: 0x00009510 File Offset: 0x00007710
			public static RESULTS scan(IntPtr start, IntPtr end, string array_of_bytes, string mask)
			{
				RESULTS result = new RESULTS();
				int i = (int)start;
				int num = (int)end;
				cbyte cbyte = new cbyte(array_of_bytes);
				while (i < num)
				{
					int default_BUFFER = mem.DEFAULT_BUFFER;
					int num2 = 0;
					byte[] array = new byte[default_BUFFER];
					bool flag = functions.ReadProcessMemory(mem.PROC, (IntPtr)i, array, default_BUFFER, ref num2);
					if (flag)
					{
						sasm.scanning.checkbytes(ref result, i, array, cbyte, mask);
					}
					i += default_BUFFER - cbyte.size();
				}
				return result;
			}

			// Token: 0x06000077 RID: 119 RVA: 0x00009598 File Offset: 0x00007798
			public static IntPtr pscan(string array_of_bytes, mem.comparisons patterns_nearby)
			{
				string text = "";
				cbyte cbyte = new cbyte(array_of_bytes);
				for (int i = 0; i < cbyte.size(); i++)
				{
					text += ".";
				}
				return sasm.scanning.scan(mem.BASE, mem.STACK_END, cbyte.to_string(), text, patterns_nearby);
			}

			// Token: 0x06000078 RID: 120 RVA: 0x000095F4 File Offset: 0x000077F4
			public static RESULTS fscan(string array_of_bytes, mem.comparisons patterns_nearby)
			{
				IntPtr intPtr = sasm.scanning.pscan(array_of_bytes, patterns_nearby);
				bool flag = intPtr == mem.PZERO;
				RESULTS result;
				if (flag)
				{
					result = new RESULTS();
				}
				else
				{
					string array_of_bytes2 = convert.bytes_le(convert.to_str(intPtr));
					result = sasm.scanning.scan(mem.BASE, mem.STACK_END, array_of_bytes2, "....");
				}
				return result;
			}
		}
	}
}
