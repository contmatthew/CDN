﻿using System;
using System.Diagnostics;
using mem_help;

namespace stat_asm
{
	// Token: 0x02000002 RID: 2
	public static class loader
	{
		// Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
		public static bool open(string ProcName, int aslr_offset)
		{
			mem.ASLR_OFFSET = aslr_offset;
			ProcName = ProcName.Replace(".exe", "");
			Process[] processes = Process.GetProcesses();
			for (int i = 0; i < processes.Length; i++)
			{
				bool flag = processes[i].ProcessName == ProcName;
				if (flag)
				{
					uint id = (uint)processes[i].Id;
					bool flag2 = id > 0u;
					if (flag2)
					{
						mem.PROC = functions.OpenProcess(1082u, 0, id);
						bool flag3 = mem.PROC != mem.PZERO;
						if (flag3)
						{
							mem.BASE = processes[i].MainModule.BaseAddress;
							mem.STACK_END = mem.BASE + 16777215 + 1;
							sasm.reader.INIT();
							return true;
						}
					}
				}
			}
			return false;
		}
	}
}
