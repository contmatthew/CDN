﻿using System;

namespace stat_asm
{
	// Token: 0x02000003 RID: 3
	public class opcode
	{
		// Token: 0x06000002 RID: 2 RVA: 0x00002126 File Offset: 0x00000326
		public opcode()
		{
			this.size = 1;
			this.bytecode = "??";
			this.asm = "[unidentified]";
			this.address = (IntPtr)0;
		}

		// Token: 0x06000003 RID: 3 RVA: 0x0000215C File Offset: 0x0000035C
		public opcode(string a, string b)
		{
			this.asm = a;
			this.bytecode = b;
			this.size = this.bytecode.Replace(" ", "").Length / 2;
			this.address = (IntPtr)0;
		}

		// Token: 0x04000001 RID: 1
		public int size;

		// Token: 0x04000002 RID: 2
		public string bytecode;

		// Token: 0x04000003 RID: 3
		public string asm;

		// Token: 0x04000004 RID: 4
		public IntPtr address;
	}
}
