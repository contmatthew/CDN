﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using mem_help;
using stat_asm;
using System.Net;

namespace STATASM
{
	// Token: 0x02000005 RID: 5
	public partial class MAIN : Form
	{
        // Token: 0x0600000E RID: 14 RVA: 0x00003083 File Offset: 0x00001283
        public MAIN()
        {
            this.InitializeComponent();
            MessageBox.Show("Created By RoboMat");
            WebClient wc = new WebClient();
            if (wc.DownloadString("http://mc.pcgaming.com/yeetdumper/integrety.txt") == "true")
            {
                MessageBox.Show("Integrety True");
            }
            else
            {
                MessageBox.Show("Integrety false");
                this.Close();
            }
        }

        // Token: 0x0600000F RID: 15 RVA: 0x000030A0 File Offset: 0x000012A0
        /*	private MAIN.function_data list_function(string fname, IntPtr func)
            {
                MAIN.function_data function_data = default(MAIN.function_data);
                function_data.name = fname;
                function_data.address = convert.to_str(mem.unbase(func));
                function_data.conventiontype = sasm.calltype(func);
                for (int i = 0; i < this.function_datas.Count; i++)
                {
                    bool flag = this.function_datas[i].name == fname;
                    if (flag)
                    {
                        return function_data;
                    }
                }
                List<string> list = sasm.fargs(func);
                for (int j = 0; j < list.Count; j++)
                {
                    function_data.args += list[j];
                    bool flag2 = j < list.Count - 1;
                    if (flag2)
                    {
                        function_data.args += ", ";
                    }
                }
                this.function_datas.Add(function_data);
                this.lbResults.Items.Add(function_data.name);
                return function_data;
            } */

        private MAIN.function_data list_function(string fname, IntPtr func)
        {
            MAIN.function_data function_data = default(MAIN.function_data);
            function_data.name = fname;
            function_data.address = convert.to_str(mem.unbase(func));
            function_data.conventiontype = sasm.calltype(func);

            ibResults.AppendText(function_data.name + ">" + function_data.address + ">" + function_data.conventiontype + "\n");
           
            return function_data;
        }

        // Token: 0x06000010 RID: 16 RVA: 0x000031B0 File Offset: 0x000013B0
    private MAIN.function_data list_address(string fname, IntPtr addr)
		{
			MAIN.function_data function_data = default(MAIN.function_data);
			function_data.name = fname;
			function_data.address = convert.to_str(mem.unbase(addr));
			function_data.conventiontype = "";
            ibResults.AppendText(function_data.name + ">" + function_data.address + ">" + "\n");
            //this.lbResults.Items.Add(function_data.name);
            return function_data;
		}

		// Token: 0x06000011 RID: 17 RVA: 0x00003218 File Offset: 0x00001418
		private void Form1_Load(object sender, EventArgs e)
		{
			bool flag = !loader.open("RobloxPlayerBeta.exe", 4194304);
			if (flag)
			{
				MessageBox.Show("Please open roblox :(", "yeet dumper");
				Application.Exit();
			}
			this.ConsoleOutput.Text = "Welcome to robo dumper :yeet:";
		}

		// Token: 0x06000012 RID: 18 RVA: 0x00003268 File Offset: 0x00001468
		private void OutputConsole(string value)
		{
			value = "<" + DateTime.Now.ToString("HH:mm:ss") + "> : " + value;
			bool flag = this.ConsoleOutput.Text.Length == 0;
			bool flag2 = flag;
			if (flag2)
			{
				this.ConsoleOutput.Text = value;
			}
			else
			{
				this.ConsoleOutput.AppendText("\r\n" + value);
			}
		}

		// Token: 0x06000013 RID: 19 RVA: 0x000032E0 File Offset: 0x000014E0
		private void btnUpdate_Click(object sender, EventArgs e)
		{
            MessageBox.Show("Wait for a message to say Found All Addresses");
			this.ConsoleOutput.Text = "Working";
			this.ConsoleOutput.Text = "Please do not close this proccess.";
			MessageBox.Show("This will stop the proccess, and will take about 1-2 mins so please be patience.", "yeet dumper");
			Thread.Sleep(1000);
            ibResults.Clear();
			RESULTS results = sasm.getcalls(sasm.scanning.fscan(convert.to_bytes("The metatable is locked").to_string(), mem.NOCMPS)[1], true);
			RESULTS results2 = sasm.getcalls(sasm.scanning.fscan(convert.to_bytes("__type").to_string(), mem.NOCMPS)[0], true);
            this.list_function("lua_createtable", results[0]);
			this.list_function("lua_createtable", results[1]);
			this.list_function("lua_pushstring", results[2]);
			this.list_function("lua_pushlstring", results[4]);
			this.list_function("lua_pushvalue", results[5]);
			this.list_function("lua_setfield", results[3]);
			this.list_function("lua_settable", results[6]);
			this.list_function("lua_setmetatable", results[7]);
			this.list_function("lua_type\t\t", results2[0]);
			this.list_function("lua_touserdata\t", results2[1]);
			this.list_function("lua_getmetatable\t", results2[2]);
			this.list_function("lua_getfield\t", results2[3]);
			this.list_function("lua_tolstring\t", results2[5]);
			IntPtr address = sasm.pnextstring(sasm.scanning.fscan(convert.to_bytes("xpcall").to_string(), mem.NOCMPS)[0], "assert", direction.BEHIND);
			IntPtr func = mem.pointer(sasm.pnextstring(address, "dofile", direction.AHEAD) + 4);
			IntPtr func2 = mem.pointer(sasm.pnextstring(address, "getfenv", direction.AHEAD) + 4);
			IntPtr func3 = mem.pointer(sasm.pnextstring(address, "setfenv", direction.AHEAD) + 4);
			IntPtr func4 = mem.pointer(sasm.pnextstring(address, "getmetatable", direction.AHEAD) + 4);
			IntPtr func5 = mem.pointer(sasm.pnextstring(address, "setmetatable", direction.AHEAD) + 4);
			IntPtr func6 = mem.pointer(sasm.pnextstring(address, "tostring", direction.AHEAD) + 4);
			IntPtr func7 = mem.pointer(sasm.pnextstring(address, "next", direction.AHEAD) + 4);
			IntPtr func8 = mem.pointer(sasm.pnextstring(address, "create", direction.AHEAD) + 4);
			IntPtr func9 = mem.pointer(sasm.pnextstring(address, "resume", direction.AHEAD) + 4);
			IntPtr func10 = mem.pointer(sasm.pnextstring(sasm.pnextstring(address, "running", direction.AHEAD) + 4, "running", direction.AHEAD) + 4);
			IntPtr func11 = mem.pointer(sasm.pnextstring(address, "wrap", direction.AHEAD) + 4);
			IntPtr func12 = mem.pointer(sasm.pnextstring(address, "yield", direction.AHEAD) + 4);
			RESULTS results3 = sasm.getcalls(func, false);
			RESULTS results4 = sasm.getcalls(func2, false);
			RESULTS results5 = sasm.getcalls(func3, false);
			RESULTS results6 = sasm.getcalls(func4, false);
			RESULTS results7 = sasm.getcalls(func5, false);
			RESULTS results8 = sasm.getcalls(func6, false);
			RESULTS results9 = sasm.getcalls(func7, false);
			RESULTS results10 = sasm.getcalls(func8, false);
			RESULTS results11 = sasm.getcalls(func9, false);
			RESULTS results12 = sasm.getcalls(func10, false);
			RESULTS results13 = sasm.getcalls(func11, false);
			sasm.getcalls(func12, false);
			this.list_function("lua_call", results3[2]);
			this.list_function("lua_getmetatable", results6[0]);
			this.list_function("lua_pushnil", results6[1]);
			this.list_function("lua_setmetatable", results7[2]);
			this.list_function("lua_settop", results7[1]);
			this.list_function("luaL_callmeta", results8[0]);
			this.list_function("luaL_getmetafield", results7[0]);
			this.list_function("luaL_checklstring", results3[0]);
			this.list_function("luaL_loadfile", results3[1]);
			this.list_function("luaL_typerror", results3[3]);
			this.list_function("lua_getfenv", results4[2]);
			this.list_function("lua_getfunc", results4[0]);
			this.list_function("lua_pushvalue", results4[1]);
			this.list_function("lua_tolstring", results8[1]);
			this.list_function("lua_pushstring", results8[2]);
			this.list_function("lua_pushvalue", results8[3]);
			this.list_function("lua_toboolean", results8[4]);
			this.list_function("lua_pushstring", results8[5]);
			this.list_function("lua_pushlstring", results8[6]);
			this.list_function("lua_tonumber", results8[7]);
			this.list_function("lua_settop", results9[0]);
			this.list_function("lua_next", results9[1]);
			this.list_function("lua_pushthread", results12[0]);
			this.list_function("lua_newthread", results10[0]);
			this.list_function("lua_pushvalue", results10[1]);
			this.list_function("lua_xmove", results10[2]);
			this.list_function("lua_pushboolean", results11[1]);
			this.list_function("lua_insert", results11[2]);
			this.list_function("lua_pushcclosure", results13[1]);
			this.list_function("lua_getfunc", results5[0]);
			this.list_function("lua_pushvalue", results5[1]);
			this.list_function("lua_isnumber", results5[2]);
			//this.lbResults.Update();
			IntPtr address2 = sasm.pnextstring(address, "concat", direction.BEHIND);
			IntPtr func13 = mem.pointer(sasm.pnextstring(address2, "foreachi", direction.AHEAD) + 4);
			IntPtr func14 = mem.pointer(sasm.pnextstring(address2, "sort", direction.AHEAD) + 4);
			RESULTS results14 = sasm.getcalls(func13, false);
			RESULTS results15 = sasm.getcalls(func14, false);
			this.list_function("lua_rawgeti", results14[2]);
			this.list_function("lua_objlen", results15[0]);
			this.list_function("lua_checkstack", results15[1]);
			this.list_function("lua_settop", results15[2]);
			IntPtr func15 = sasm.nextcall(sasm.scanning.fscan(convert.to_bytes("*** Value").to_string(), mem.NOCMPS)[0], direction.BEHIND);
			this.list_function("lua_pcall", func15);
			IntPtr addr = mem.PZERO;
			IntPtr pointer = mem.PZERO;
			IntPtr pointer2 = sasm.nextcall(sasm.getcalls(func15, true)[1], direction.AHEAD);
			for (int i = 0; i < 528; i++)
			{
				bool flag = mem.sreadb(pointer2 + i, 2) == "81 0D" && mem.sreadb(pointer2 + i + 6, 4) == "00 00 80 03";
				if (flag)
				{
					pointer = pointer2 + i;
				}
			}
			for (int j = 0; j < 32; j++)
			{
				bool flag2 = mem.readb(pointer - j) == 116;
				if (flag2)
				{
					addr = pointer - j;
				}
			}
			this.list_address("rawrjz", addr);
			IntPtr intPtr = mem.PZERO;
			intPtr = sasm.nextprologue(sasm.scanning.fscan(convert.to_bytes("Script Context").to_string(), mem.NOCMPS)[0], direction.BEHIND);
			List<opcode> list = sasm.reader.read(intPtr, intPtr + 168);
			bool flag3 = false;
			for (int k = 0; k < list.Count - 1; k++)
			{
				bool flag4 = mem.sreadb(list[k].address, 2) == "C7 03";
				if (flag4)
				{
					bool flag5 = !flag3;
					if (flag5)
					{
						flag3 = true;
					}
					else
					{
						intPtr = mem.pointer(list[k].address + 2);
					}
				}
			}
			this.list_address("Script Context", intPtr);
            MessageBox.Show("Found All Addresses");
		}

		// Token: 0x06000014 RID: 20 RVA: 0x00003B68 File Offset: 0x00001D68


		// Token: 0x06000015 RID: 21 RVA: 0x00003BD8 File Offset: 0x00001DD8
		private void btnLS_Click(object sender, EventArgs e)
		{
			bool flag = this.btnLS.Text == "Find Lua State";
			if (flag)
			{
				this.btnLS.Update();
				IntPtr pointer = sasm.scanning.fscan(convert.to_bytes("Running Script \"%s\"").to_string(), mem.NOCMPS)[0] + 25;
				sasm.subroutine subroutine = new sasm.subroutine();
				for (int i = 0; i < 128; i++)
				{
					bool flag2 = mem.sreadb(pointer + i, 3) == "0F 45 CA";
					if (flag2)
					{
						subroutine.start = pointer + i + 3;
					}
				}
				for (int j = 0; j < 64; j++)
				{
					bool flag3 = mem.sreadb(subroutine.start + j, 1) == sasm.refer.CALL;
					if (flag3)
					{
						subroutine.size = j - 1;
						break;
					}
				}
				List<opcode> list = sasm.reader.read(subroutine.start, subroutine.start + subroutine.size);
				string text = "";
				text += "int esi = ScriptContext;\n";
				text += "int ecx = 0;\n";
				for (int k = 0; k < list.Count; k++)
				{
					opcode opcode = list[k];
					bool flag4 = mem.sreadb(opcode.address, 3) == "8D 04 CD";
					if (flag4)
					{
						text = string.Concat(new object[]
						{
							text,
							"eax += ",
							mem.readi(opcode.address + 3),
							" + (ecx * 8)"
						});
					}
					else
					{
						bool flag5 = mem.sreadb(opcode.address, 3) == "8D 04 C5";
						if (flag5)
						{
							text = string.Concat(new object[]
							{
								text,
								"eax += ",
								mem.readi(opcode.address + 3),
								" + (eax * 8)"
							});
						}
						else
						{
							bool flag6 = mem.sreadb(opcode.address, 1) == "2B";
							if (flag6)
							{
								text = text + opcode.asm.Substring(4, 3) + " -= " + opcode.asm.Substring(8, 3);
							}
							else
							{
								bool flag7 = mem.sreadb(opcode.address, 1) == "03";
								if (flag7)
								{
									text = text + opcode.asm.Substring(4, 3) + " += " + opcode.asm.Substring(8, 3);
								}
								else
								{
									bool flag8 = mem.sreadb(opcode.address, 1) == "33";
									if (flag8)
									{
										text = text + opcode.asm.Substring(4, 3) + " ^= " + opcode.asm.Substring(8, 3);
									}
									else
									{
										bool flag9 = mem.sreadb(opcode.address, 1) == "8B" && opcode.asm.Substring(7, 2) == ",[";
										if (flag9)
										{
											text = text + opcode.asm.Substring(4, 3) + " = *(int*)" + opcode.asm.Substring(9, 3);
										}
										else
										{
											text = text + opcode.asm + " ?? )";
										}
									}
								}
							}
						}
					}
					text += ";\n";
				}
				text += "int LuaState = esi;";
				Form form = new Form();
				form.Name = "LStateForm";
				form.Text = "Lua State Psuedocode";
				form.Size = new Size(220, 220);
				form.ShowIcon = false;
				RichTextBox richTextBox = new RichTextBox();
				richTextBox.Parent = form;
				richTextBox.Size = new Size(form.Width - 24, form.Height - 50);
				richTextBox.Location = new Point(4, 4);
				richTextBox.Text = text;
				richTextBox.Parent = form;
				form.Show();
				this.btnLS.Text = "Lua State";
			}
		}

		// Token: 0x06000016 RID: 22 RVA: 0x00004038 File Offset: 0x00002238
		private void btnSC_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000017 RID: 23 RVA: 0x00004038 File Offset: 0x00002238
		private void txtFunc_TextChanged(object sender, EventArgs e)
		{
		}

		// Token: 0x06000018 RID: 24 RVA: 0x00004038 File Offset: 0x00002238
		private void pictureBox1_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x04000005 RID: 5
		private List<MAIN.function_data> function_datas = new List<MAIN.function_data>();

		// Token: 0x0200001F RID: 31
		private struct function_data
		{
			// Token: 0x04000086 RID: 134
			public string name;

			// Token: 0x04000087 RID: 135
			public string address;

			// Token: 0x04000088 RID: 136
			public string conventiontype;

			// Token: 0x04000089 RID: 137
			public string args;
		}

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
