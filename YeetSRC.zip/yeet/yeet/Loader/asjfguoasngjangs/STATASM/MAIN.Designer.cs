﻿namespace STATASM
{
	// Token: 0x02000005 RID: 5
	public partial class MAIN : global::System.Windows.Forms.Form
	{
		// Token: 0x06000019 RID: 25 RVA: 0x0000403C File Offset: 0x0000223C
		protected override void Dispose(bool disposing)
		{
			bool flag = disposing && this.components != null;
			if (flag)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600001A RID: 26 RVA: 0x00004074 File Offset: 0x00002274
		private void InitializeComponent()
		{
            this.txtFunc = new System.Windows.Forms.TextBox();
            this.txtAddr = new System.Windows.Forms.TextBox();
            this.txtConv = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnLS = new System.Windows.Forms.Button();
            this.txtArgs = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.ConsoleOutput = new System.Windows.Forms.RichTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.ibResults = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // txtFunc
            // 
            this.txtFunc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.txtFunc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFunc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.txtFunc.ForeColor = System.Drawing.Color.White;
            this.txtFunc.Location = new System.Drawing.Point(12, 12);
            this.txtFunc.Name = "txtFunc";
            this.txtFunc.ReadOnly = true;
            this.txtFunc.Size = new System.Drawing.Size(156, 21);
            this.txtFunc.TabIndex = 4;
            this.txtFunc.TextChanged += new System.EventHandler(this.txtFunc_TextChanged);
            // 
            // txtAddr
            // 
            this.txtAddr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.txtAddr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAddr.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.txtAddr.ForeColor = System.Drawing.Color.White;
            this.txtAddr.Location = new System.Drawing.Point(336, 12);
            this.txtAddr.Name = "txtAddr";
            this.txtAddr.ReadOnly = true;
            this.txtAddr.Size = new System.Drawing.Size(156, 21);
            this.txtAddr.TabIndex = 5;
            // 
            // txtConv
            // 
            this.txtConv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.txtConv.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtConv.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.txtConv.ForeColor = System.Drawing.Color.White;
            this.txtConv.Location = new System.Drawing.Point(174, 12);
            this.txtConv.Name = "txtConv";
            this.txtConv.ReadOnly = true;
            this.txtConv.Size = new System.Drawing.Size(156, 21);
            this.txtConv.TabIndex = 6;
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.btnUpdate.FlatAppearance.BorderSize = 0;
            this.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdate.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.ForeColor = System.Drawing.Color.White;
            this.btnUpdate.Location = new System.Drawing.Point(187, 293);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(154, 32);
            this.btnUpdate.TabIndex = 7;
            this.btnUpdate.Text = "Find Address";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnLS
            // 
            this.btnLS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.btnLS.FlatAppearance.BorderSize = 0;
            this.btnLS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLS.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLS.ForeColor = System.Drawing.Color.White;
            this.btnLS.Location = new System.Drawing.Point(12, 293);
            this.btnLS.Name = "btnLS";
            this.btnLS.Size = new System.Drawing.Size(154, 32);
            this.btnLS.TabIndex = 8;
            this.btnLS.Text = "Find Lua State";
            this.btnLS.UseVisualStyleBackColor = false;
            this.btnLS.Click += new System.EventHandler(this.btnLS_Click);
            // 
            // txtArgs
            // 
            this.txtArgs.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.txtArgs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtArgs.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.txtArgs.ForeColor = System.Drawing.Color.White;
            this.txtArgs.Location = new System.Drawing.Point(498, 12);
            this.txtArgs.Name = "txtArgs";
            this.txtArgs.ReadOnly = true;
            this.txtArgs.Size = new System.Drawing.Size(209, 21);
            this.txtArgs.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(185, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 11);
            this.label1.TabIndex = 12;
            this.label1.Text = "Calling Convention";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(386, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 11);
            this.label2.TabIndex = 13;
            this.label2.Text = "Address";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(52, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 11);
            this.label3.TabIndex = 14;
            this.label3.Text = "Functions";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(590, 36);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 11);
            this.label4.TabIndex = 15;
            this.label4.Text = "Args";
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(36)))));
            this.richTextBox1.Font = new System.Drawing.Font("Lucida Console", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.ForeColor = System.Drawing.Color.White;
            this.richTextBox1.Location = new System.Drawing.Point(372, 50);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(371, 188);
            this.richTextBox1.TabIndex = 16;
            this.richTextBox1.Text = "- 40 addys\n- If ther process freezes, dont worry its finding\n- tested by thunder\n" +
    "- created by RoboMat\n- Absolute for orginal source (finding open source libs, an" +
    "d a slow source)";
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // ConsoleOutput
            // 
            this.ConsoleOutput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(36)))));
            this.ConsoleOutput.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ConsoleOutput.ForeColor = System.Drawing.Color.White;
            this.ConsoleOutput.Location = new System.Drawing.Point(372, 258);
            this.ConsoleOutput.Name = "ConsoleOutput";
            this.ConsoleOutput.ReadOnly = true;
            this.ConsoleOutput.Size = new System.Drawing.Size(371, 74);
            this.ConsoleOutput.TabIndex = 17;
            this.ConsoleOutput.Text = "";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(534, 241);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 11);
            this.label5.TabIndex = 18;
            this.label5.Text = "Output";
            // 
            // ibResults
            // 
            this.ibResults.Location = new System.Drawing.Point(2, 50);
            this.ibResults.Name = "ibResults";
            this.ibResults.Size = new System.Drawing.Size(364, 237);
            this.ibResults.TabIndex = 19;
            this.ibResults.Text = "";
            // 
            // MAIN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(36)))));
            this.ClientSize = new System.Drawing.Size(755, 337);
            this.Controls.Add(this.ibResults);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.ConsoleOutput);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtArgs);
            this.Controls.Add(this.btnLS);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.txtConv);
            this.Controls.Add(this.txtAddr);
            this.Controls.Add(this.txtFunc);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "MAIN";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RoboDumper";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		// Token: 0x04000006 RID: 6
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000008 RID: 8
		private global::System.Windows.Forms.TextBox txtFunc;

		// Token: 0x04000009 RID: 9
		private global::System.Windows.Forms.TextBox txtAddr;

		// Token: 0x0400000A RID: 10
		private global::System.Windows.Forms.TextBox txtConv;

		// Token: 0x0400000B RID: 11
		private global::System.Windows.Forms.Button btnUpdate;

		// Token: 0x0400000C RID: 12
		private global::System.Windows.Forms.Button btnLS;

		// Token: 0x0400000D RID: 13
		private global::System.Windows.Forms.TextBox txtArgs;

		// Token: 0x0400000E RID: 14
		private global::System.Windows.Forms.Label label1;

		// Token: 0x0400000F RID: 15
		private global::System.Windows.Forms.Label label2;

		// Token: 0x04000010 RID: 16
		private global::System.Windows.Forms.Label label3;

		// Token: 0x04000011 RID: 17
		private global::System.Windows.Forms.Label label4;

		// Token: 0x04000012 RID: 18
		private global::System.Windows.Forms.RichTextBox richTextBox1;

		// Token: 0x04000013 RID: 19
		private global::System.Windows.Forms.RichTextBox ConsoleOutput;

		// Token: 0x04000014 RID: 20
		private global::System.Windows.Forms.Label label5;
        private System.Windows.Forms.RichTextBox ibResults;
    }
}
