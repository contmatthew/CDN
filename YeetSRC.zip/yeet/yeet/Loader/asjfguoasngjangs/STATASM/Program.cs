﻿using System;
using System.Windows.Forms;

namespace STATASM
{
	// Token: 0x02000006 RID: 6
	internal static class Program
	{
		// Token: 0x0600001B RID: 27 RVA: 0x00004C6A File Offset: 0x00002E6A
		[STAThread]
		private static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new MAIN());
		}
	}
}
