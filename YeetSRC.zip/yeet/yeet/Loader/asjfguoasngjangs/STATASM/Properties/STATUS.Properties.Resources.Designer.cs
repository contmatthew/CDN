﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace asjfguoasngjangs.STATASM.Properties
{
	// Token: 0x02000008 RID: 8
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "15.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	internal class STATUS_Properties_Resources
	{
		// Token: 0x0600001F RID: 31 RVA: 0x00004CBE File Offset: 0x00002EBE
		internal STATUS_Properties_Resources()
		{
		}

		// Token: 0x17000002 RID: 2
		// (get) Token: 0x06000020 RID: 32 RVA: 0x00004CC8 File Offset: 0x00002EC8
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				bool flag = STATUS_Properties_Resources.resourceMan == null;
				if (flag)
				{
					ResourceManager resourceManager = new ResourceManager("asjfguoasngjangs.STATASM.Properties.STATUS.Properties.Resources", typeof(STATUS_Properties_Resources).Assembly);
					STATUS_Properties_Resources.resourceMan = resourceManager;
				}
				return STATUS_Properties_Resources.resourceMan;
			}
		}

		// Token: 0x17000003 RID: 3
		// (get) Token: 0x06000021 RID: 33 RVA: 0x00004D10 File Offset: 0x00002F10
		// (set) Token: 0x06000022 RID: 34 RVA: 0x00004D27 File Offset: 0x00002F27
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return STATUS_Properties_Resources.resourceCulture;
			}
			set
			{
				STATUS_Properties_Resources.resourceCulture = value;
			}
		}

		// Token: 0x04000016 RID: 22
		private static ResourceManager resourceMan;

		// Token: 0x04000017 RID: 23
		private static CultureInfo resourceCulture;
	}
}
