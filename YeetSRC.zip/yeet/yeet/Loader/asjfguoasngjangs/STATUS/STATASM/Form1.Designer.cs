﻿namespace STATUS.STATASM
{
	// Token: 0x02000019 RID: 25
	public partial class Form1 : global::System.Windows.Forms.Form
	{
		// Token: 0x06000063 RID: 99 RVA: 0x000066E4 File Offset: 0x000048E4
		protected override void Dispose(bool disposing)
		{
			bool flag = disposing && this.components != null;
			if (flag)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000064 RID: 100 RVA: 0x0000671B File Offset: 0x0000491B
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(800, 450);
			this.Text = "Form1";
		}

		// Token: 0x04000055 RID: 85
		private global::System.ComponentModel.IContainer components = null;
	}
}
