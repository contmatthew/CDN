﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace STATUS.STATASM
{
	// Token: 0x02000019 RID: 25
	public partial class Form1 : Form
	{
		// Token: 0x06000062 RID: 98 RVA: 0x000066CB File Offset: 0x000048CB
		public Form1()
		{
			this.InitializeComponent();
		}
	}
}
