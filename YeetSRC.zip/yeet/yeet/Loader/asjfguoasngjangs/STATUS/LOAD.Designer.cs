﻿namespace STATUS
{
	// Token: 0x02000018 RID: 24
	public partial class LOAD : global::System.Windows.Forms.Form
	{
		// Token: 0x06000060 RID: 96 RVA: 0x0000665C File Offset: 0x0000485C
		protected override void Dispose(bool disposing)
		{
			bool flag = disposing && this.components != null;
			if (flag)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000061 RID: 97 RVA: 0x00006693 File Offset: 0x00004893
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(800, 450);
			this.Text = "LOAD";
		}

		// Token: 0x04000054 RID: 84
		private global::System.ComponentModel.IContainer components = null;
	}
}
