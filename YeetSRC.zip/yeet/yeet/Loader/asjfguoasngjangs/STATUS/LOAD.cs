﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace STATUS
{
	// Token: 0x02000018 RID: 24
	public partial class LOAD : Form
	{
		// Token: 0x0600005F RID: 95 RVA: 0x00006641 File Offset: 0x00004841
		public LOAD()
		{
			this.InitializeComponent();
		}
	}
}
