﻿using System;
using System.Globalization;
using System.Text;

namespace mem_help
{
	// Token: 0x0200000F RID: 15
	public static class convert
	{
		// Token: 0x06000033 RID: 51 RVA: 0x000050C8 File Offset: 0x000032C8
		public static byte to_hex(string hexstr_byte)
		{
			byte b = 0;
			bool flag = hexstr_byte.Substring(0, 2) != "0x";
			if (flag)
			{
				hexstr_byte = "0x" + hexstr_byte;
			}
			bool flag2 = hexstr_byte == "0x??";
			byte result;
			if (flag2)
			{
				result = b;
			}
			else
			{
				for (int i = 0; i < convert.str_hex.Length; i++)
				{
					bool flag3 = hexstr_byte == convert.str_hex[i];
					if (flag3)
					{
						b = convert.hex_data[i];
						break;
					}
				}
				result = b;
			}
			return result;
		}

		// Token: 0x06000034 RID: 52 RVA: 0x00005154 File Offset: 0x00003354
		public static string to_str(byte b, bool hex)
		{
			string text = "";
			int i = 0;
			while (i < convert.hex_data.Length)
			{
				bool flag = b == convert.hex_data[i];
				if (flag)
				{
					if (hex)
					{
						text = convert.str_hex[i];
						break;
					}
					text += convert.str_hex[i][2].ToString();
					text += convert.str_hex[i][3].ToString();
					break;
				}
				else
				{
					i++;
				}
			}
			return text;
		}

		// Token: 0x06000035 RID: 53 RVA: 0x000051E8 File Offset: 0x000033E8
		public static short to_short(byte b1, byte b2)
		{
			return BitConverter.ToInt16(new byte[]
			{
				b1,
				b2
			}, 0);
		}

		// Token: 0x06000036 RID: 54 RVA: 0x00005210 File Offset: 0x00003410
		public static int to_int(byte b1, byte b2, byte b3, byte b4)
		{
			return BitConverter.ToInt32(new byte[]
			{
				b1,
				b2,
				b3,
				b4
			}, 0);
		}

		// Token: 0x06000037 RID: 55 RVA: 0x00005240 File Offset: 0x00003440
		public static float to_float(byte b1, byte b2, byte b3, byte b4)
		{
			return BitConverter.ToSingle(new byte[]
			{
				b1,
				b2,
				b3,
				b4
			}, 0);
		}

		// Token: 0x06000038 RID: 56 RVA: 0x00005270 File Offset: 0x00003470
		public static double to_double(byte b1, byte b2, byte b3, byte b4, byte b5, byte b6, byte b7, byte b8)
		{
			return BitConverter.ToDouble(new byte[]
			{
				b1,
				b2,
				b3,
				b4,
				b5,
				b6,
				b7,
				b8
			}, 0);
		}

		// Token: 0x06000039 RID: 57 RVA: 0x000052B4 File Offset: 0x000034B4
		public static cbyte to_bytes(string v)
		{
			cbyte cbyte = new cbyte();
			byte[] bytes = Encoding.ASCII.GetBytes(v);
			for (int i = 0; i < bytes.Length; i++)
			{
				cbyte.push(bytes[i]);
			}
			return cbyte;
		}

		// Token: 0x0600003A RID: 58 RVA: 0x000052FC File Offset: 0x000034FC
		public static cbyte to_bytes(short v)
		{
			cbyte cbyte = new cbyte();
			byte[] bytes = BitConverter.GetBytes(v);
			for (int i = 0; i < bytes.Length; i++)
			{
				cbyte.push(bytes[i]);
			}
			return cbyte;
		}

		// Token: 0x0600003B RID: 59 RVA: 0x0000533C File Offset: 0x0000353C
		public static cbyte to_bytes(int v)
		{
			cbyte cbyte = new cbyte();
			byte[] bytes = BitConverter.GetBytes(v);
			for (int i = 0; i < bytes.Length; i++)
			{
				cbyte.push(bytes[i]);
			}
			return cbyte;
		}

		// Token: 0x0600003C RID: 60 RVA: 0x0000537C File Offset: 0x0000357C
		public static cbyte to_bytes(float v)
		{
			cbyte cbyte = new cbyte();
			byte[] bytes = BitConverter.GetBytes(v);
			for (int i = 0; i < bytes.Length; i++)
			{
				cbyte.push(bytes[i]);
			}
			return cbyte;
		}

		// Token: 0x0600003D RID: 61 RVA: 0x000053BC File Offset: 0x000035BC
		public static cbyte to_bytes(double v)
		{
			cbyte cbyte = new cbyte();
			byte[] bytes = BitConverter.GetBytes(v);
			for (int i = 0; i < bytes.Length; i++)
			{
				cbyte.push(bytes[i]);
			}
			return cbyte;
		}

		// Token: 0x0600003E RID: 62 RVA: 0x000053FC File Offset: 0x000035FC
		public static IntPtr to_addr(string s)
		{
			return (IntPtr)(BitConverter.ToInt32(BitConverter.GetBytes(uint.Parse(s.Replace("0x", ""), NumberStyles.AllowHexSpecifier)), 0) | 0);
		}

		// Token: 0x0600003F RID: 63 RVA: 0x0000543C File Offset: 0x0000363C
		public static string to_str(IntPtr addr)
		{
			string text = addr.ToString("X8");
			bool flag = text.Substring(0, 2) == "00";
			if (flag)
			{
				text = addr.ToString("X6");
			}
			return text;
		}

		// Token: 0x06000040 RID: 64 RVA: 0x00005484 File Offset: 0x00003684
		public static string bytes_le(string str)
		{
			str = str.Replace(" ", "");
			bool flag = str.Length == 8;
			string result;
			if (flag)
			{
				string text = "";
				string text2 = "";
				string text3 = "";
				string text4 = "";
				text += str[0].ToString();
				text += str[1].ToString();
				text2 += str[2].ToString();
				text2 += str[3].ToString();
				text3 += str[4].ToString();
				text3 += str[5].ToString();
				text4 += str[6].ToString();
				text4 += str[7].ToString();
				result = string.Concat(new string[]
				{
					text4,
					" ",
					text3,
					" ",
					text2,
					" ",
					text
				});
			}
			else
			{
				result = str;
			}
			return result;
		}

		// Token: 0x06000041 RID: 65 RVA: 0x000055CC File Offset: 0x000037CC
		public static cbyte to_bytes(IntPtr addr)
		{
			return new cbyte(convert.bytes_le(convert.to_str(addr).Replace("0x", "")));
		}

		// Token: 0x04000034 RID: 52
		private static string[] str_hex = new string[]
		{
			"0x00",
			"0x01",
			"0x02",
			"0x03",
			"0x04",
			"0x05",
			"0x06",
			"0x07",
			"0x08",
			"0x09",
			"0x0A",
			"0x0B",
			"0x0C",
			"0x0D",
			"0x0E",
			"0x0F",
			"0x10",
			"0x11",
			"0x12",
			"0x13",
			"0x14",
			"0x15",
			"0x16",
			"0x17",
			"0x18",
			"0x19",
			"0x1A",
			"0x1B",
			"0x1C",
			"0x1D",
			"0x1E",
			"0x1F",
			"0x20",
			"0x21",
			"0x22",
			"0x23",
			"0x24",
			"0x25",
			"0x26",
			"0x27",
			"0x28",
			"0x29",
			"0x2A",
			"0x2B",
			"0x2C",
			"0x2D",
			"0x2E",
			"0x2F",
			"0x30",
			"0x31",
			"0x32",
			"0x33",
			"0x34",
			"0x35",
			"0x36",
			"0x37",
			"0x38",
			"0x39",
			"0x3A",
			"0x3B",
			"0x3C",
			"0x3D",
			"0x3E",
			"0x3F",
			"0x40",
			"0x41",
			"0x42",
			"0x43",
			"0x44",
			"0x45",
			"0x46",
			"0x47",
			"0x48",
			"0x49",
			"0x4A",
			"0x4B",
			"0x4C",
			"0x4D",
			"0x4E",
			"0x4F",
			"0x50",
			"0x51",
			"0x52",
			"0x53",
			"0x54",
			"0x55",
			"0x56",
			"0x57",
			"0x58",
			"0x59",
			"0x5A",
			"0x5B",
			"0x5C",
			"0x5D",
			"0x5E",
			"0x5F",
			"0x60",
			"0x61",
			"0x62",
			"0x63",
			"0x64",
			"0x65",
			"0x66",
			"0x67",
			"0x68",
			"0x69",
			"0x6A",
			"0x6B",
			"0x6C",
			"0x6D",
			"0x6E",
			"0x6F",
			"0x70",
			"0x71",
			"0x72",
			"0x73",
			"0x74",
			"0x75",
			"0x76",
			"0x77",
			"0x78",
			"0x79",
			"0x7A",
			"0x7B",
			"0x7C",
			"0x7D",
			"0x7E",
			"0x7F",
			"0x80",
			"0x81",
			"0x82",
			"0x83",
			"0x84",
			"0x85",
			"0x86",
			"0x87",
			"0x88",
			"0x89",
			"0x8A",
			"0x8B",
			"0x8C",
			"0x8D",
			"0x8E",
			"0x8F",
			"0x90",
			"0x91",
			"0x92",
			"0x93",
			"0x94",
			"0x95",
			"0x96",
			"0x97",
			"0x98",
			"0x99",
			"0x9A",
			"0x9B",
			"0x9C",
			"0x9D",
			"0x9E",
			"0x9F",
			"0xA0",
			"0xA1",
			"0xA2",
			"0xA3",
			"0xA4",
			"0xA5",
			"0xA6",
			"0xA7",
			"0xA8",
			"0xA9",
			"0xAA",
			"0xAB",
			"0xAC",
			"0xAD",
			"0xAE",
			"0xAF",
			"0xB0",
			"0xB1",
			"0xB2",
			"0xB3",
			"0xB4",
			"0xB5",
			"0xB6",
			"0xB7",
			"0xB8",
			"0xB9",
			"0xBA",
			"0xBB",
			"0xBC",
			"0xBD",
			"0xBE",
			"0xBF",
			"0xC0",
			"0xC1",
			"0xC2",
			"0xC3",
			"0xC4",
			"0xC5",
			"0xC6",
			"0xC7",
			"0xC8",
			"0xC9",
			"0xCA",
			"0xCB",
			"0xCC",
			"0xCD",
			"0xCE",
			"0xCF",
			"0xD0",
			"0xD1",
			"0xD2",
			"0xD3",
			"0xD4",
			"0xD5",
			"0xD6",
			"0xD7",
			"0xD8",
			"0xD9",
			"0xDA",
			"0xDB",
			"0xDC",
			"0xDD",
			"0xDE",
			"0xDF",
			"0xE0",
			"0xE1",
			"0xE2",
			"0xE3",
			"0xE4",
			"0xE5",
			"0xE6",
			"0xE7",
			"0xE8",
			"0xE9",
			"0xEA",
			"0xEB",
			"0xEC",
			"0xED",
			"0xEE",
			"0xEF",
			"0xF0",
			"0xF1",
			"0xF2",
			"0xF3",
			"0xF4",
			"0xF5",
			"0xF6",
			"0xF7",
			"0xF8",
			"0xF9",
			"0xFA",
			"0xFB",
			"0xFC",
			"0xFD",
			"0xFE",
			"0xFF"
		};

		// Token: 0x04000035 RID: 53
		private static byte[] hex_data = new byte[]
		{
			0,
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8,
			9,
			10,
			11,
			12,
			13,
			14,
			15,
			16,
			17,
			18,
			19,
			20,
			21,
			22,
			23,
			24,
			25,
			26,
			27,
			28,
			29,
			30,
			31,
			32,
			33,
			34,
			35,
			36,
			37,
			38,
			39,
			40,
			41,
			42,
			43,
			44,
			45,
			46,
			47,
			48,
			49,
			50,
			51,
			52,
			53,
			54,
			55,
			56,
			57,
			58,
			59,
			60,
			61,
			62,
			63,
			64,
			65,
			66,
			67,
			68,
			69,
			70,
			71,
			72,
			73,
			74,
			75,
			76,
			77,
			78,
			79,
			80,
			81,
			82,
			83,
			84,
			85,
			86,
			87,
			88,
			89,
			90,
			91,
			92,
			93,
			94,
			95,
			96,
			97,
			98,
			99,
			100,
			101,
			102,
			103,
			104,
			105,
			106,
			107,
			108,
			109,
			110,
			111,
			112,
			113,
			114,
			115,
			116,
			117,
			118,
			119,
			120,
			121,
			122,
			123,
			124,
			125,
			126,
			127,
			128,
			129,
			130,
			131,
			132,
			133,
			134,
			135,
			136,
			137,
			138,
			139,
			140,
			141,
			142,
			143,
			144,
			145,
			146,
			147,
			148,
			149,
			150,
			151,
			152,
			153,
			154,
			155,
			156,
			157,
			158,
			159,
			160,
			161,
			162,
			163,
			164,
			165,
			166,
			167,
			168,
			169,
			170,
			171,
			172,
			173,
			174,
			175,
			176,
			177,
			178,
			179,
			180,
			181,
			182,
			183,
			184,
			185,
			186,
			187,
			188,
			189,
			190,
			191,
			192,
			193,
			194,
			195,
			196,
			197,
			198,
			199,
			200,
			201,
			202,
			203,
			204,
			205,
			206,
			207,
			208,
			209,
			210,
			211,
			212,
			213,
			214,
			215,
			216,
			217,
			218,
			219,
			220,
			221,
			222,
			223,
			224,
			225,
			226,
			227,
			228,
			229,
			230,
			231,
			232,
			233,
			234,
			235,
			236,
			237,
			238,
			239,
			240,
			241,
			242,
			243,
			244,
			245,
			246,
			247,
			248,
			249,
			250,
			251,
			252,
			253,
			254,
			byte.MaxValue
		};
	}
}
