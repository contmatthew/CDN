﻿using System;

namespace mem_help
{
	// Token: 0x02000016 RID: 22
	public struct PROCESS_INFORMATION
	{
		// Token: 0x04000050 RID: 80
		public IntPtr hProcess;

		// Token: 0x04000051 RID: 81
		public IntPtr hThread;

		// Token: 0x04000052 RID: 82
		public int dwProcessId;

		// Token: 0x04000053 RID: 83
		public int dwThreadId;
	}
}
