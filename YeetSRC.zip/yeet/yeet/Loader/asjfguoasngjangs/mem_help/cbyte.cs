﻿using System;
using System.Collections.Generic;

namespace mem_help
{
	// Token: 0x0200000B RID: 11
	public class cbyte
	{
		// Token: 0x06000028 RID: 40 RVA: 0x00004DA1 File Offset: 0x00002FA1
		public cbyte()
		{
			this.bytes = new List<byte>();
		}

		// Token: 0x06000029 RID: 41 RVA: 0x00004DB8 File Offset: 0x00002FB8
		public cbyte(string s)
		{
			this.bytes = new List<byte>();
			string text = s.Replace(" ", "");
			bool flag = text.Length == 2;
			if (flag)
			{
				this.bytes.Add(convert.to_hex(text));
			}
			else
			{
				bool flag2 = text.Length % 2 == 0;
				if (flag2)
				{
					int num = 0;
					while (num < text.Length && num + 1 <= text.Length)
					{
						byte item = convert.to_hex(text[num].ToString() + text[num + 1].ToString());
						this.bytes.Add(item);
						num += 2;
					}
				}
			}
		}

		// Token: 0x0600002A RID: 42 RVA: 0x00004E82 File Offset: 0x00003082
		public void push(byte b)
		{
			this.bytes.Add(b);
		}

		// Token: 0x0600002B RID: 43 RVA: 0x00004E94 File Offset: 0x00003094
		public byte at(int i)
		{
			return this.bytes[i];
		}

		// Token: 0x0600002C RID: 44 RVA: 0x00004EB4 File Offset: 0x000030B4
		public void set(int pos, byte value)
		{
			bool flag = this.bytes.Count >= pos;
			if (flag)
			{
				this.bytes[pos] = value;
			}
		}

		// Token: 0x0600002D RID: 45 RVA: 0x00004EE8 File Offset: 0x000030E8
		public int size()
		{
			return this.bytes.Count;
		}

		// Token: 0x0600002E RID: 46 RVA: 0x00004F08 File Offset: 0x00003108
		public string to_string()
		{
			string text = "";
			for (int i = 0; i < this.bytes.Count; i++)
			{
				text += convert.to_str(this.bytes[i], false);
				bool flag = i < this.bytes.Count - 1;
				if (flag)
				{
					text += " ";
				}
			}
			return text;
		}

		// Token: 0x0600002F RID: 47 RVA: 0x00004F7C File Offset: 0x0000317C
		public string to_text()
		{
			string text = "";
			for (int i = 0; i < this.bytes.Count; i++)
			{
				bool flag = this.bytes[i] >= 32 && this.bytes[i] <= 126;
				if (flag)
				{
					text += Convert.ToChar(this.bytes[i]).ToString();
				}
				else
				{
					text += " ";
				}
			}
			return text;
		}

		// Token: 0x06000030 RID: 48 RVA: 0x00005014 File Offset: 0x00003214
		public byte[] get_bytes()
		{
			byte[] array = new byte[this.bytes.Count];
			for (int i = 0; i < this.bytes.Count; i++)
			{
				array[i] = this.bytes[i];
			}
			return array;
		}

		// Token: 0x06000031 RID: 49 RVA: 0x00005064 File Offset: 0x00003264
		public bool compare(cbyte s)
		{
			bool flag = this.size() != s.size();
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				for (int i = 0; i < s.size(); i++)
				{
					bool flag2 = s.at(i) != this.at(i);
					if (flag2)
					{
						return false;
					}
				}
				result = true;
			}
			return result;
		}

		// Token: 0x04000025 RID: 37
		private List<byte> bytes;
	}
}
