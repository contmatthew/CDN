﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace mem_help
{
	// Token: 0x02000012 RID: 18
	public static class mem
	{
		// Token: 0x0600004D RID: 77 RVA: 0x000060B0 File Offset: 0x000042B0
		public static IntPtr addr(int int32addr)
		{
			return (IntPtr)int32addr;
		}

		// Token: 0x0600004E RID: 78 RVA: 0x000060C8 File Offset: 0x000042C8
		public static IntPtr aslr(IntPtr addr)
		{
			return addr - mem.ASLR_OFFSET + (int)mem.BASE;
		}

		// Token: 0x0600004F RID: 79 RVA: 0x000060F4 File Offset: 0x000042F4
		public static IntPtr unbase(IntPtr addr)
		{
			return addr - (int)mem.BASE + mem.ASLR_OFFSET;
		}

		// Token: 0x06000050 RID: 80 RVA: 0x00006120 File Offset: 0x00004320
		public static MEM_PROTECT vprotect(IntPtr address, int size, uint new_protect)
		{
			MEM_PROTECT mem_PROTECT = new MEM_PROTECT();
			MEMORY_BASIC_INFORMATION memory_BASIC_INFORMATION;
			functions.VirtualQueryEx(mem.PROC, address, out memory_BASIC_INFORMATION, (uint)Marshal.SizeOf(typeof(MEMORY_BASIC_INFORMATION)));
			functions.VirtualProtectEx(mem.PROC, memory_BASIC_INFORMATION.BaseAddress, (IntPtr)size, new_protect, out memory_BASIC_INFORMATION.Protect);
			mem_PROTECT.size = (long)size;
			mem_PROTECT.address = address;
			mem_PROTECT.protection_data = memory_BASIC_INFORMATION;
			return mem_PROTECT;
		}

		// Token: 0x06000051 RID: 81 RVA: 0x0000618C File Offset: 0x0000438C
		public static void vrestore(MEM_PROTECT protection)
		{
			uint num;
			functions.VirtualProtectEx(mem.PROC, protection.protection_data.BaseAddress, (IntPtr)protection.size, protection.protection_data.Protect, out num);
		}

		// Token: 0x06000052 RID: 82 RVA: 0x000061C8 File Offset: 0x000043C8
		public static string sreadb(IntPtr address, int count)
		{
			string text = "";
			bool flag = false;
			int num = 0;
			byte[] array = new byte[count];
			bool flag2 = mem.PROC != mem.PZERO;
			if (flag2)
			{
				flag = functions.ReadProcessMemory(mem.PROC, address, array, count, ref num);
			}
			bool flag3 = !flag;
			if (flag3)
			{
				for (int i = 0; i < array.Length; i++)
				{
					text += "??";
					bool flag4 = i < array.Length - 1;
					if (flag4)
					{
						text += " ";
					}
				}
			}
			else
			{
				for (int j = 0; j < array.Length; j++)
				{
					text += convert.to_str(array[j], false);
					bool flag5 = j < array.Length - 1;
					if (flag5)
					{
						text += " ";
					}
				}
			}
			return text;
		}

		// Token: 0x06000053 RID: 83 RVA: 0x000062B0 File Offset: 0x000044B0
		public static string sreadb(IntPtr address)
		{
			byte[] array = new byte[1];
			int num = 0;
			bool flag = mem.PROC != mem.PZERO && functions.ReadProcessMemory(mem.PROC, address, array, 1, ref num);
			string result;
			if (flag)
			{
				result = convert.to_str(array[0], false);
			}
			else
			{
				result = "??";
			}
			return result;
		}

		// Token: 0x06000054 RID: 84 RVA: 0x00006304 File Offset: 0x00004504
		public static byte readb(IntPtr address)
		{
			byte[] array = new byte[1];
			int num = 0;
			bool flag = mem.PROC != mem.PZERO && functions.ReadProcessMemory(mem.PROC, address, array, 1, ref num);
			byte result;
			if (flag)
			{
				result = array[0];
			}
			else
			{
				result = 0;
			}
			return result;
		}

		// Token: 0x06000055 RID: 85 RVA: 0x00006350 File Offset: 0x00004550
		public static short reads(IntPtr address)
		{
			byte[] array = new byte[2];
			int num = 0;
			bool flag = mem.PROC != mem.PZERO && functions.ReadProcessMemory(mem.PROC, address, array, 2, ref num);
			short result;
			if (flag)
			{
				result = BitConverter.ToInt16(array, 0);
			}
			else
			{
				result = 0;
			}
			return result;
		}

		// Token: 0x06000056 RID: 86 RVA: 0x000063A0 File Offset: 0x000045A0
		public static int readi(IntPtr address)
		{
			byte[] array = new byte[4];
			int num = 0;
			bool flag = mem.PROC != mem.PZERO && functions.ReadProcessMemory(mem.PROC, address, array, 4, ref num);
			int result;
			if (flag)
			{
				result = BitConverter.ToInt32(array, 0);
			}
			else
			{
				result = 0;
			}
			return result;
		}

		// Token: 0x06000057 RID: 87 RVA: 0x000063F0 File Offset: 0x000045F0
		public static float readf(IntPtr address)
		{
			byte[] array = new byte[4];
			int num = 0;
			bool flag = mem.PROC != mem.PZERO && functions.ReadProcessMemory(mem.PROC, address, array, 4, ref num);
			float result;
			if (flag)
			{
				result = BitConverter.ToSingle(array, 0);
			}
			else
			{
				result = 0f;
			}
			return result;
		}

		// Token: 0x06000058 RID: 88 RVA: 0x00006444 File Offset: 0x00004644
		public static double readd(IntPtr address)
		{
			byte[] array = new byte[8];
			int num = 0;
			bool flag = mem.PROC != mem.PZERO && functions.ReadProcessMemory(mem.PROC, address, array, 8, ref num);
			double result;
			if (flag)
			{
				result = BitConverter.ToDouble(array, 0);
			}
			else
			{
				result = 0.0;
			}
			return result;
		}

		// Token: 0x06000059 RID: 89 RVA: 0x0000649C File Offset: 0x0000469C
		public static string sreads(IntPtr address, int length)
		{
			string text = "";
			bool flag = mem.PROC != mem.PZERO;
			if (flag)
			{
				for (int i = 0; i < length; i++)
				{
					byte b = mem.readb(address + i);
					bool flag2 = b >= 32 && b <= 126;
					if (flag2)
					{
						text += Convert.ToChar(b).ToString();
					}
					else
					{
						text += "?";
					}
				}
			}
			return text;
		}

		// Token: 0x0600005A RID: 90 RVA: 0x0000652C File Offset: 0x0000472C
		public static string sreads(IntPtr address)
		{
			string text = "";
			bool flag = mem.PROC != mem.PZERO;
			if (flag)
			{
				int num = 0;
				while (mem.readb(address + num) >= 32 && mem.readb(address + num) <= 126)
				{
					text += mem.sreads(address + num, 1);
					num++;
				}
			}
			return text;
		}

		// Token: 0x0600005B RID: 91 RVA: 0x000065A4 File Offset: 0x000047A4
		public static IntPtr pointer(IntPtr addr)
		{
			cbyte cbyte = new cbyte(mem.sreadb(addr, 4));
			bool flag = cbyte.size() == 4;
			IntPtr result;
			if (flag)
			{
				result = convert.to_addr(convert.to_str(cbyte.at(3), false) + convert.to_str(cbyte.at(2), false) + convert.to_str(cbyte.at(1), false) + convert.to_str(cbyte.at(0), false));
			}
			else
			{
				result = mem.PZERO;
			}
			return result;
		}

		// Token: 0x04000039 RID: 57
		public static IntPtr PZERO = (IntPtr)0;

		// Token: 0x0400003A RID: 58
		public static IntPtr PROC;

		// Token: 0x0400003B RID: 59
		public static IntPtr BASE;

		// Token: 0x0400003C RID: 60
		public static IntPtr STACK_END;

		// Token: 0x0400003D RID: 61
		public static int ASLR_OFFSET;

		// Token: 0x0400003E RID: 62
		public static int DEFAULT_BUFFER = 262144;

		// Token: 0x0400003F RID: 63
		public static mem.comparisons NOCMPS = new mem.comparisons();

		// Token: 0x02000020 RID: 32
		public class comparisons
		{
			// Token: 0x06000079 RID: 121 RVA: 0x00009647 File Offset: 0x00007847
			public comparisons()
			{
				this.LIST = new List<cmpdata>();
			}

			// Token: 0x0600007A RID: 122 RVA: 0x0000965C File Offset: 0x0000785C
			public void Add(int offset, comparison_option option, string bytes_cmp)
			{
				bool flag = option == comparison_option.EQUAL;
				if (flag)
				{
					cmpdata cmpdata = new cmpdata();
					cmpdata.offset = offset;
					cmpdata.bytes_cmp = bytes_cmp.Replace(" ", "");
					cmpdata.type = comparison_type.OFFSET_EQUAL_TO;
					this.LIST.Add(cmpdata);
				}
				else
				{
					bool flag2 = option == comparison_option.NOT_EQUAL;
					if (flag2)
					{
						cmpdata cmpdata2 = new cmpdata();
						cmpdata2.offset = offset;
						cmpdata2.bytes_cmp = bytes_cmp.Replace(" ", "");
						cmpdata2.type = comparison_type.OFFSET_NOT_EQUAL_TO;
						this.LIST.Add(cmpdata2);
					}
				}
			}

			// Token: 0x0600007B RID: 123 RVA: 0x000096F0 File Offset: 0x000078F0
			public void Add(int pointeroffset, int offset, comparison_option option, string bytes_cmp)
			{
				bool flag = option == comparison_option.EQUAL;
				if (flag)
				{
					cmpdata cmpdata = new cmpdata();
					cmpdata.pointeroffset = pointeroffset;
					cmpdata.offset = offset;
					cmpdata.bytes_cmp = bytes_cmp.Replace(" ", "");
					cmpdata.type = comparison_type.OFFSET_PTR_OFFSET_EQUAL_TO;
					this.LIST.Add(cmpdata);
				}
				else
				{
					bool flag2 = option == comparison_option.NOT_EQUAL;
					if (flag2)
					{
						cmpdata cmpdata2 = new cmpdata();
						cmpdata2.pointeroffset = pointeroffset;
						cmpdata2.offset = offset;
						cmpdata2.bytes_cmp = bytes_cmp.Replace(" ", "");
						cmpdata2.type = comparison_type.OFFSET_PTR_OFFSET_NOT_EQUAL_TO;
						this.LIST.Add(cmpdata2);
					}
				}
			}

			// Token: 0x0400008A RID: 138
			public List<cmpdata> LIST;
		}
	}
}
