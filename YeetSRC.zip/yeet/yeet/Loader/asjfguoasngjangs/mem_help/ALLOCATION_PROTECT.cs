﻿using System;

namespace mem_help
{
	// Token: 0x0200000A RID: 10
	public class ALLOCATION_PROTECT
	{
		// Token: 0x0400001A RID: 26
		public const uint PAGE_EXECUTE = 16u;

		// Token: 0x0400001B RID: 27
		public const uint PAGE_EXECUTE_READ = 32u;

		// Token: 0x0400001C RID: 28
		public const uint PAGE_EXECUTE_READWRITE = 64u;

		// Token: 0x0400001D RID: 29
		public const uint PAGE_EXECUTE_WRITECOPY = 128u;

		// Token: 0x0400001E RID: 30
		public const uint PAGE_NOACCESS = 1u;

		// Token: 0x0400001F RID: 31
		public const uint PAGE_READONLY = 2u;

		// Token: 0x04000020 RID: 32
		public const uint PAGE_READWRITE = 4u;

		// Token: 0x04000021 RID: 33
		public const uint PAGE_WRITECOPY = 8u;

		// Token: 0x04000022 RID: 34
		public const uint PAGE_GUARD = 256u;

		// Token: 0x04000023 RID: 35
		public const uint PAGE_NOCACHE = 512u;

		// Token: 0x04000024 RID: 36
		public const uint PAGE_WRITECOMBINE = 1024u;
	}
}
