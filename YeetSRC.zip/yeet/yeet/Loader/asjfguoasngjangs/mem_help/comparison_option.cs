﻿using System;

namespace mem_help
{
	// Token: 0x0200000D RID: 13
	public enum comparison_option
	{
		// Token: 0x0400002C RID: 44
		NO_OFFSET,
		// Token: 0x0400002D RID: 45
		EQUAL,
		// Token: 0x0400002E RID: 46
		NOT_EQUAL
	}
}
