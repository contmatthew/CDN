﻿using System;

namespace mem_help
{
	// Token: 0x02000014 RID: 20
	public class MEM_PROTECT
	{
		// Token: 0x04000047 RID: 71
		public MEMORY_BASIC_INFORMATION protection_data;

		// Token: 0x04000048 RID: 72
		public IntPtr address;

		// Token: 0x04000049 RID: 73
		public long size;
	}
}
