﻿using System;

namespace mem_help
{
	// Token: 0x02000010 RID: 16
	public enum direction
	{
		// Token: 0x04000037 RID: 55
		BEHIND,
		// Token: 0x04000038 RID: 56
		AHEAD
	}
}
