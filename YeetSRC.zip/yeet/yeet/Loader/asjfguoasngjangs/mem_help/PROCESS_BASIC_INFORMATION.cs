﻿using System;

namespace mem_help
{
	// Token: 0x02000015 RID: 21
	internal struct PROCESS_BASIC_INFORMATION
	{
		// Token: 0x0400004A RID: 74
		public IntPtr Reserved1;

		// Token: 0x0400004B RID: 75
		public IntPtr PebAddress;

		// Token: 0x0400004C RID: 76
		public IntPtr Reserved2;

		// Token: 0x0400004D RID: 77
		public IntPtr Reserved3;

		// Token: 0x0400004E RID: 78
		public IntPtr UniquePid;

		// Token: 0x0400004F RID: 79
		public IntPtr MoreReserved;
	}
}
