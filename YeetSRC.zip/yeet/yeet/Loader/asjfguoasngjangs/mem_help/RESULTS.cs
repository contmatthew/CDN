﻿using System;
using System.Collections.Generic;

namespace mem_help
{
	// Token: 0x02000017 RID: 23
	public class RESULTS : List<IntPtr>
	{
	}
}
