﻿using System;

namespace mem_help
{
	// Token: 0x0200000C RID: 12
	public class cmpdata
	{
		// Token: 0x04000026 RID: 38
		public int pointeroffset;

		// Token: 0x04000027 RID: 39
		public int offset;

		// Token: 0x04000028 RID: 40
		public byte value;

		// Token: 0x04000029 RID: 41
		public string bytes_cmp;

		// Token: 0x0400002A RID: 42
		public comparison_type type;
	}
}
