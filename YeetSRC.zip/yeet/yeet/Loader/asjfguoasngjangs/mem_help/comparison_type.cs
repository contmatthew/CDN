﻿using System;

namespace mem_help
{
	// Token: 0x0200000E RID: 14
	public enum comparison_type
	{
		// Token: 0x04000030 RID: 48
		OFFSET_EQUAL_TO,
		// Token: 0x04000031 RID: 49
		OFFSET_NOT_EQUAL_TO,
		// Token: 0x04000032 RID: 50
		OFFSET_PTR_OFFSET_EQUAL_TO,
		// Token: 0x04000033 RID: 51
		OFFSET_PTR_OFFSET_NOT_EQUAL_TO
	}
}
